"""API del Copiloto NFL. Ejecuta: .venv/bin/uvicorn backend.main:app --reload"""
import os
from pathlib import Path


def cargar_env():
    f = Path(__file__).resolve().parent.parent / ".env"
    if f.exists():
        for linea in f.read_text(encoding="utf-8-sig").splitlines():
            linea = linea.strip()
            if linea and not linea.startswith("#") and "=" in linea:
                k, v = linea.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


cargar_env()

# Todo lo que puede usar boto3 o importar ai_agent va después de cargar_env().
from contextlib import asynccontextmanager  # noqa: E402

import pandas as pd  # noqa: E402
from fastapi import FastAPI, HTTPException, Query, Request  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

from backend import metrics  # noqa: E402
from backend.coach import Coach, load_external, to_jsonable  # noqa: E402
from backend.coach_local import LocalCoach  # noqa: E402
from backend.data_loader import DATA, ROOT, DataStore, load_store  # noqa: E402
from backend.schemas import (  # noqa: E402
    CoachRequest, CoachResponse, EfficiencyResponse, FourthDownRequest, FourthDownResponse,
    MatchupResponse, MetaResponse, TeamInfo, TeamRow,
)

DIST = ROOT / "dashboard" / "dist"
AUTO = object()


def _records(df: pd.DataFrame) -> list[dict]:
    return df.astype(object).where(df.notna(), None).to_dict("records")


def _row(s: pd.Series) -> dict:
    return {k: (None if pd.isna(v) else getattr(v, "item", lambda: v)()) for k, v in s.items()}


def create_app(data_dir: Path = DATA, external=AUTO) -> FastAPI:
    """external: AUTO importa ai_agent.bedrock_coach; None fuerza el respaldo local; un objeto se usa tal cual."""

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        store = load_store(data_dir)
        app.state.store = store
        app.state.coach = Coach(LocalCoach(store), load_external() if external is AUTO else external)
        yield

    app = FastAPI(title="Hackathon NFL UNAM", lifespan=lifespan)

    def state(request: Request) -> tuple[DataStore, Coach]:
        return request.app.state.store, request.app.state.coach

    def season_or_latest(s: DataStore, season: int | None) -> int:
        return season if season is not None else (s.seasons[-1] if s.seasons else 0)

    def compute_matchup(s: DataStore, coach: Coach, home: str, away: str, season: int | None, exclude: bool):
        home, away = home.upper(), away.upper()
        if home == away:
            raise HTTPException(400, "Selecciona dos equipos distintos")
        season = season_or_latest(s, season)
        df = s.efficiency[exclude]
        try:
            result = metrics.matchup(df[df["season"] == season], home, away)
            context = coach.get_matchup_context(home, away)
        except KeyError as exc:
            raise HTTPException(404, f"Sin datos para el equipo {exc.args[0]} en la temporada {season}") from None
        except ValueError as exc:
            raise HTTPException(404, str(exc) or "Equipo sin datos") from None
        result["home"] = _row(result["home"])
        result["away"] = _row(result["away"])
        return season, result, context

    def compute_fourth(s: DataStore, coach: Coach, ydstogo: int, yardline_100: int) -> dict:
        sim = metrics.simulate_fourth_down(s.fourth_down, ydstogo, yardline_100)
        context = coach.get_fourth_down_context(ydstogo, yardline_100)
        warnings = [w for w in context.get("warnings", []) if isinstance(w, str)]
        if sim["low_sample"]:
            warnings.append(f"Muestra pequeña: solo {sim['sample_size']} jugadas en esta situación.")
        return {**sim, "warnings": list(dict.fromkeys(warnings)), "context": context,
                "simulated": s.simulated.get("fourth_down", False)}

    @app.get("/health")
    def health() -> dict:
        return {"status": "ok"}

    @app.get("/api/meta", response_model=MetaResponse)
    def meta(request: Request):
        s, coach = state(request)
        info = s.efficiency[True].drop_duplicates("posteam").set_index("posteam", drop=False)
        teams = [TeamInfo(**_row(info.loc[t][list(TeamInfo.model_fields)])) for t in coach.list_teams() if t in info.index]
        return MetaResponse(simulated=s.simulated, any_simulated=s.any_simulated, seasons=s.seasons,
                            teams=teams, coach_source=coach.source)

    @app.get("/api/efficiency", response_model=EfficiencyResponse)
    def efficiency(request: Request, season: int | None = None, exclude_garbage_time: bool = True):
        s, _ = state(request)
        season = season_or_latest(s, season)
        df = s.efficiency[exclude_garbage_time]
        rows = df[df["season"] == season]
        return EfficiencyResponse(season=season, exclude_garbage_time=exclude_garbage_time,
                                  simulated=s.any_simulated, teams=[TeamRow(**r) for r in _records(rows)])

    @app.get("/api/matchup", response_model=MatchupResponse)
    def matchup(
        request: Request,
        home: str = Query(min_length=2, max_length=3),
        away: str = Query(min_length=2, max_length=3),
        season: int | None = None,
        exclude_garbage_time: bool = True,
    ):
        s, coach = state(request)
        season, result, context = compute_matchup(s, coach, home, away, season, exclude_garbage_time)
        return MatchupResponse(season=season, exclude_garbage_time=exclude_garbage_time,
                               simulated=s.any_simulated, context=context, **result)

    @app.post("/api/fourth-down/simulate", response_model=FourthDownResponse)
    def simulate(request: Request, body: FourthDownRequest):
        s, coach = state(request)
        return FourthDownResponse(**compute_fourth(s, coach, body.ydstogo, body.yardline_100))

    @app.post("/api/coach/ask", response_model=CoachResponse)
    def ask(request: Request, body: CoachRequest):
        """Único endpoint que consulta al copiloto (Bedrock). El contexto se arma aquí, nunca en el cliente."""
        s, coach = state(request)
        if body.topic == "matchup":
            _, result, context = compute_matchup(s, coach, body.home, body.away, body.season, body.exclude_garbage_time)
            full = {"tipo": "matchup", "comparacion": result, "contexto": context}
        else:
            sim = compute_fourth(s, coach, body.ydstogo, body.yardline_100)
            context = sim.pop("context")
            sim.pop("zone_curve")
            full = {"tipo": "fourth_down", "simulacion": sim, "contexto": context}
        return CoachResponse(**coach.ask(body.question, to_jsonable(full)))

    if DIST.is_dir():
        app.mount("/", StaticFiles(directory=DIST, html=True), name="dashboard")

    return app


app = create_app()
