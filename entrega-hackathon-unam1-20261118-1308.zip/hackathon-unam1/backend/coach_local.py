"""Respaldo local de ai_agent/bedrock_coach.py: mismas firmas, calculado con el DataStore."""
from __future__ import annotations

import pandas as pd

from backend import advisor, metrics
from backend.data_loader import DataStore

RANKED = metrics.PRIMARY_METRICS + metrics.COMPLEMENTARY_METRICS


def _clean(v):
    if v is None:
        return None
    if isinstance(v, float) and pd.isna(v):
        return None
    return getattr(v, "item", lambda: v)()


class LocalCoach:
    source = "backend"

    def __init__(self, store: DataStore):
        self.store = store

    def _season_df(self) -> pd.DataFrame:
        eff = self.store.efficiency[True]
        latest = eff["season"].max()
        return eff[eff["season"] == latest]

    def list_teams(self) -> list[str]:
        return sorted(self._season_df()["posteam"].tolist())

    def get_matchup_context(self, team_a: str, team_b: str) -> dict:
        df = self._season_df().set_index("posteam")
        for t in (team_a, team_b):
            if t not in df.index:
                raise ValueError(f"Sin datos para el equipo {t}")
        ranks = {
            m: df[m].rank(ascending=m in metrics.LOWER_IS_BETTER, method="min")
            for m in RANKED if m in df.columns
        }

        def team(t: str) -> dict:
            row = df.loc[t]
            out = {"posteam": t, "team_name": _clean(row.get("team_name")), "plays": _clean(row.get("plays"))}
            for m in RANKED:
                out[m] = _clean(row.get(m))
                r = ranks[m].get(t)
                out[f"{m}_rank"] = None if pd.isna(r) else int(r)
            return out

        return {
            "season": int(self._season_df()["season"].max()),
            "teams_in_league": int(len(df)),
            "team_a": team(team_a),
            "team_b": team(team_b),
            "league_avg": {m: round(float(df[m].mean()), 4) for m in RANKED if m in df.columns},
        }

    def get_fourth_down_context(self, ydstogo: int, yardline_100: int) -> dict:
        fd = self.store.fourth_down
        zone = metrics.field_zone(yardline_100)
        zone_rows = fd[fd["field_zone"] == zone]
        exact = zone_rows[zone_rows["ydstogo"] == ydstogo]
        nearby = zone_rows[(zone_rows["ydstogo"] - ydstogo).abs() <= 2].sort_values("ydstogo")

        def rec(r) -> dict:
            return {"ydstogo": int(r["ydstogo"]), "field_zone": r["field_zone"],
                    "go_for_it_epa": float(r["go_for_it_epa"]), "conversion_prob": float(r["conversion_prob"]),
                    "sample_size": int(r["sample_size"])}

        warnings = []
        if ydstogo > 10:
            warnings.append(f"Los datos solo cubren 4ta y 1 a 4ta y 10; 4ta y {ydstogo} se aproxima con la distancia más cercana.")
        if exact.empty:
            warnings.append(f"No hay jugadas históricas de 4ta y {ydstogo} en esta zona.")
        else:
            n = int(exact.iloc[0]["sample_size"])
            if n < metrics.MIN_SAMPLE:
                warnings.append(f"Muestra pequeña: solo {n} jugadas en esta situación.")
        warnings.append("Sin datos históricos de gol de campo ni de despeje (el dataset solo tiene pases).")
        return {
            "situation": {"ydstogo": ydstogo, "yardline_100": yardline_100, "field_zone": zone},
            "exact": rec(exact.iloc[0]) if not exact.empty else None,
            "nearby": [rec(r) for _, r in nearby.iterrows()],
            "warnings": warnings,
        }

    def ask(self, question: str, context: dict) -> dict:
        try:
            return {"text": advisor.ask_bedrock(question, context), "ai_generated": True, "source": "backend"}
        except Exception as exc:  # Bedrock no disponible: texto determinista
            advisor.log.warning("Bedrock no disponible: %s", type(exc).__name__)
            return {"text": advisor.fallback_text(question, context), "ai_generated": False, "source": "determinista"}
