"""Cálculos puros sobre DataFrames: métricas por equipo, matchups y 4ta oportunidad.

Las fórmulas replican backend/scripts/transform_bdb (1).py para que el recálculo
sin tiempo basura coincida con data/team_efficiency.csv.
"""
from __future__ import annotations

import math

import pandas as pd

PRIMARY_METRICS = ["epa_per_play", "success_rate", "pass_epa", "run_epa", "cpoe", "def_epa_per_play"]
COMPLEMENTARY_METRICS = ["yards_per_play", "completion_pct", "sack_rate"]
LOWER_IS_BETTER = {"def_epa_per_play", "sack_rate"}

GO_MIN_PROB = 0.50
MIN_SAMPLE = 5
FG_MAX_YARDLINE = 37

ZONE_RED = "RedZone (1-20)"
ZONE_OPP = "Opponent Territory (21-50)"
ZONE_OWN = "Own Territory (51-99)"

KEYS = ["posteam", "season"]


def _filter(plays: pd.DataFrame, exclude_garbage_time: bool) -> pd.DataFrame:
    return plays[~plays["garbage_time"]] if exclude_garbage_time else plays


def team_metrics(plays: pd.DataFrame, exclude_garbage_time: bool) -> pd.DataFrame:
    """Métricas principales (EPA) por equipo y temporada, igual que team_efficiency.csv."""
    df = _filter(plays, exclude_garbage_time)
    success = df["epa"] > 0
    is_pass = df["play_type"] == "pass"
    is_run = df["play_type"] == "run"
    early = df["down"].isin([1, 2])

    off = df.groupby(KEYS)
    out = pd.DataFrame({
        "plays": off.size(),
        "epa_per_play": off["epa"].mean(),
        "success_rate": success.groupby([df["posteam"], df["season"]]).mean(),
        "pass_epa": df[is_pass].groupby(KEYS)["epa"].mean(),
        "run_epa": df[is_run].groupby(KEYS)["epa"].mean(),
        "cpoe": df[is_pass].groupby(KEYS)["cpoe"].mean(),
        "early_down_pass_rate": is_pass[early].groupby([df.loc[early, "posteam"], df.loc[early, "season"]]).mean(),
    })
    out.index.names = KEYS

    defense = pd.DataFrame({
        "def_epa_per_play": df.groupby(["defteam", "season"])["epa"].mean(),
        "def_success_rate": success.groupby([df["defteam"], df["season"]]).mean(),
    })
    defense.index.names = KEYS
    return out.join(defense, how="left").reset_index()


def complementary_metrics(plays: pd.DataFrame, exclude_garbage_time: bool) -> pd.DataFrame:
    """Yardas por jugada, % de pases completos y % de capturas por equipo y temporada."""
    df = _filter(plays, exclude_garbage_time)
    by = [df["posteam"], df["season"]]
    result = df["pass_result"]
    attempts = result.isin(["C", "I", "IN"]).groupby(by).sum()
    completions = (result == "C").groupby(by).sum()
    out = pd.DataFrame({
        "yards_per_play": df["yards_gained"].groupby(by).mean(),
        "completion_pct": (completions / attempts.where(attempts > 0)),
        "sack_rate": (result == "S").groupby(by).mean(),
    })
    out.index.names = KEYS
    return out.reset_index()


def fourth_down_from_plays(plays: pd.DataFrame) -> pd.DataFrame:
    """Mismo esquema que fourth_down_situations.csv (se usa solo con datos simulados)."""
    df = plays[(plays["down"] == 4) & plays["ydstogo"].between(1, 10)].copy()
    df["field_zone"] = df["yardline_100"].map(field_zone)
    return (
        df.groupby(["ydstogo", "field_zone"])
        .agg(go_for_it_epa=("epa", "mean"), conversion_prob=("first_down", "mean"), sample_size=("epa", "size"))
        .reset_index()
    )


def _num(x) -> float | None:
    if x is None:
        return None
    try:
        if math.isnan(x):
            return None
    except TypeError:
        return None
    return float(x)


def compare(metric: str, home, away) -> dict:
    h, a = _num(home), _num(away)
    lower = metric in LOWER_IS_BETTER
    if h is None or a is None:
        return {"metric": metric, "home": h, "away": a, "diff": None, "better": "tie", "lower_is_better": lower}
    diff = round(h - a, 4)
    if diff == 0:
        better = "tie"
    elif (diff > 0) != lower:
        better = "home"
    else:
        better = "away"
    return {"metric": metric, "home": h, "away": a, "diff": diff, "better": better, "lower_is_better": lower}


def _cross(off: pd.Series, deff: pd.Series) -> dict:
    o, d = float(off["epa_per_play"]), float(deff["def_epa_per_play"])
    return {
        "offense_team": off["posteam"],
        "defense_team": deff["posteam"],
        "offense_epa": o,
        "defense_epa_allowed": d,
        "edge": round(o + d, 4),
    }


def matchup(eff: pd.DataFrame, home: str, away: str) -> dict:
    """eff debe contener una sola temporada. Lanza KeyError con el equipo sin datos."""
    rows = eff.set_index("posteam", drop=False)
    for team in (home, away):
        if team not in rows.index:
            raise KeyError(team)
    h, a = rows.loc[home], rows.loc[away]
    return {
        "home": h,
        "away": a,
        "primary": [compare(m, h[m], a[m]) for m in PRIMARY_METRICS],
        "complementary": [compare(m, h[m], a[m]) for m in COMPLEMENTARY_METRICS],
        "home_offense_vs_away_defense": _cross(h, a),
        "away_offense_vs_home_defense": _cross(a, h),
    }


def field_zone(yardline_100: int) -> str:
    if yardline_100 <= 20:
        return ZONE_RED
    if yardline_100 <= 50:
        return ZONE_OPP
    return ZONE_OWN


def _pct(p: float) -> str:
    return f"{p * 100:.1f} %"


def recommend(conversion_prob: float, sample_size: int, yardline_100: int) -> tuple[str, str]:
    """Regla_4th_Down. Devuelve (opción, explicación en español)."""
    if conversion_prob >= GO_MIN_PROB and sample_size >= MIN_SAMPLE:
        return "go_for_it", (
            f"Intentar: la conversión histórica es {_pct(conversion_prob)} (≥ 50 %) "
            f"con una muestra de {sample_size} jugadas (≥ {MIN_SAMPLE})."
        )
    reasons = []
    if conversion_prob < GO_MIN_PROB:
        reasons.append(f"conversión de {_pct(conversion_prob)} < 50 %")
    if sample_size < MIN_SAMPLE:
        reasons.append(f"muestra de {sample_size} jugadas < {MIN_SAMPLE}")
    why = " y ".join(reasons)
    if yardline_100 <= FG_MAX_YARDLINE:
        return "field_goal", (
            f"Gol de campo: no conviene intentar ({why}) y el balón está a {yardline_100} yardas "
            f"de la zona de anotación (≤ {FG_MAX_YARDLINE}, patada de ~{yardline_100 + 17} yardas)."
        )
    return "punt", (
        f"Despeje: no conviene intentar ({why}) y a {yardline_100} yardas de la zona de anotación "
        f"el gol de campo queda fuera de rango (> {FG_MAX_YARDLINE})."
    )


def simulate_fourth_down(fd: pd.DataFrame, ydstogo: int, yardline_100: int) -> dict:
    zone = field_zone(yardline_100)
    candidates = fd[fd["field_zone"] == zone]
    if candidates.empty:
        candidates = fd
    dist = (candidates["ydstogo"] - ydstogo).abs()
    ranked = candidates.assign(_d=dist).sort_values(["_d", "ydstogo"], kind="mergesort")
    row = ranked.iloc[0]

    prob = float(row["conversion_prob"])
    n = int(row["sample_size"])
    option, rule = recommend(prob, n, yardline_100)
    curve = fd[fd["field_zone"] == row["field_zone"]].sort_values("ydstogo")
    return {
        "ydstogo": ydstogo,
        "yardline_100": yardline_100,
        "field_zone": zone,
        "matched_ydstogo": int(row["ydstogo"]),
        "matched_field_zone": str(row["field_zone"]),
        "exact_match": int(row["ydstogo"]) == ydstogo and row["field_zone"] == zone,
        "go_for_it_epa": float(row["go_for_it_epa"]),
        "conversion_prob": prob,
        "sample_size": n,
        "low_sample": n < MIN_SAMPLE,
        "field_goal_available": yardline_100 <= FG_MAX_YARDLINE,
        "recommendation": option,
        "rule": rule,
        "zone_curve": [
            {"ydstogo": int(r.ydstogo), "conversion_prob": float(r.conversion_prob), "sample_size": int(r.sample_size)}
            for r in curve.itertuples()
        ],
    }
