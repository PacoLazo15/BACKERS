"""Adaptador: usa ai_agent/bedrock_coach.py si está disponible y el respaldo local si no.

Importar este módulo solo después de cargar_env() (lo hace backend/main.py).
"""
from __future__ import annotations

import importlib
import logging
import math
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from typing import Any

import numpy as np
import pandas as pd

from backend import advisor
from backend.coach_local import LocalCoach

log = logging.getLogger(__name__)

REQUIRED = ("list_teams", "get_matchup_context", "get_fourth_down_context", "ask_front_office_coach")
ASK_TIMEOUT = 30.0
_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="coach")


def load_external(name: str = "ai_agent.bedrock_coach"):
    """Devuelve el módulo del equipo o None si no existe, falla al importar o está incompleto."""
    try:
        mod = importlib.import_module(name)
    except Exception as exc:
        log.info("Copiloto externo no disponible (%s); se usa el respaldo local", type(exc).__name__)
        return None
    missing = [n for n in REQUIRED if not callable(getattr(mod, n, None))]
    if missing:
        log.warning("%s no define %s; se usa el respaldo local", name, missing)
        return None
    return mod


def to_jsonable(obj: Any) -> Any:
    """Convierte numpy/pandas a tipos nativos y NaN/inf a None, recursivamente."""
    if isinstance(obj, pd.DataFrame):
        return to_jsonable(obj.to_dict("records"))
    if isinstance(obj, pd.Series):
        return to_jsonable(obj.to_dict())
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return to_jsonable(obj.tolist())
    if isinstance(obj, np.generic):
        obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    if obj is pd.NA or obj is pd.NaT:
        return None
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return str(obj)


def _extract_text(result: Any) -> str:
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, dict):
        for key in ("text", "answer", "response", "respuesta"):
            if isinstance(result.get(key), str):
                return result[key].strip()
    return ""


class Coach:
    def __init__(self, local: LocalCoach, external=None, ask_timeout: float = ASK_TIMEOUT):
        self.local = local
        self.external = external
        self.ask_timeout = ask_timeout

    @property
    def source(self) -> str:
        return "ai_agent" if self.external is not None else "backend"

    def _call(self, name: str, *args):
        """Llama a la función externa; ValueError se propaga, otros errores usan el respaldo local."""
        if self.external is not None:
            try:
                return to_jsonable(getattr(self.external, name)(*args))
            except ValueError:
                raise
            except Exception as exc:
                log.warning("ai_agent.%s falló (%s); se usa el respaldo local", name, type(exc).__name__)
        return to_jsonable(getattr(self.local, name)(*args))

    def list_teams(self) -> list[str]:
        local = self.local.list_teams()
        teams = self._call("list_teams")
        valid = [t for t in (teams or []) if isinstance(t, str) and t in set(local)]
        return valid or local

    def get_matchup_context(self, team_a: str, team_b: str) -> dict:
        ctx = self._call("get_matchup_context", team_a, team_b)
        return ctx if isinstance(ctx, dict) else {"data": ctx}

    def get_fourth_down_context(self, ydstogo: int, yardline_100: int) -> dict:
        ctx = self._call("get_fourth_down_context", ydstogo, yardline_100)
        return ctx if isinstance(ctx, dict) else {"data": ctx}

    def ask(self, question: str, context: dict) -> dict:
        """Única vía hacia Bedrock. Solo la invoca POST /api/coach/ask."""
        context = to_jsonable(context)
        if self.external is not None:
            future = _pool.submit(self.external.ask_front_office_coach, question, context)
            try:
                text = _extract_text(future.result(timeout=self.ask_timeout))
                if text:
                    return {"text": text, "ai_generated": True, "source": "ai_agent"}
                log.warning("ai_agent.ask_front_office_coach devolvió una respuesta vacía")
            except FutureTimeout:
                log.warning("ai_agent.ask_front_office_coach superó %.0f s", self.ask_timeout)
            except Exception as exc:
                log.warning("ai_agent.ask_front_office_coach falló (%s)", type(exc).__name__)
            # Sin segunda llamada a Bedrock: evita gastar créditos dos veces por una sola consulta.
            return {"text": advisor.fallback_text(question, context), "ai_generated": False, "source": "determinista"}
        return self.local.ask(question, context)
