"""Modelos Pydantic de entrada y salida de la API."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

Option = Literal["go_for_it", "field_goal", "punt"]
Better = Literal["home", "away", "tie"]


class TeamRow(BaseModel):
    posteam: str
    season: int
    plays: int
    team_name: str
    team_conf: str | None = None
    team_division: str | None = None
    team_color: str
    team_color2: str | None = None
    epa_per_play: float
    success_rate: float
    pass_epa: float | None = None
    run_epa: float | None = None
    cpoe: float | None = None
    early_down_pass_rate: float | None = None
    def_epa_per_play: float | None = None
    def_success_rate: float | None = None
    yards_per_play: float | None = None
    completion_pct: float | None = None
    sack_rate: float | None = None


class TeamInfo(BaseModel):
    posteam: str
    team_name: str
    team_conf: str | None = None
    team_division: str | None = None
    team_color: str
    team_color2: str | None = None


class MetaResponse(BaseModel):
    simulated: dict[str, bool]
    any_simulated: bool
    seasons: list[int]
    teams: list[TeamInfo]
    coach_source: Literal["ai_agent", "backend"]


class EfficiencyResponse(BaseModel):
    season: int
    exclude_garbage_time: bool
    simulated: bool
    teams: list[TeamRow]


class MetricComparison(BaseModel):
    metric: str
    home: float | None
    away: float | None
    diff: float | None
    better: Better
    lower_is_better: bool


class CrossMatchup(BaseModel):
    offense_team: str
    defense_team: str
    offense_epa: float
    defense_epa_allowed: float
    edge: float


class MatchupResponse(BaseModel):
    season: int
    exclude_garbage_time: bool
    home: TeamRow
    away: TeamRow
    primary: list[MetricComparison]
    complementary: list[MetricComparison]
    home_offense_vs_away_defense: CrossMatchup
    away_offense_vs_home_defense: CrossMatchup
    simulated: bool
    context: dict[str, Any]


class FourthDownRequest(BaseModel):
    ydstogo: int = Field(ge=1, le=30, strict=True, description="Yardas por avanzar (1-30)")
    yardline_100: int = Field(ge=1, le=99, strict=True, description="Yardas hasta la zona de anotación (1-99)")


class ZonePoint(BaseModel):
    ydstogo: int
    conversion_prob: float
    sample_size: int


class FourthDownResponse(BaseModel):
    ydstogo: int
    yardline_100: int
    field_zone: str
    matched_ydstogo: int
    matched_field_zone: str
    exact_match: bool
    go_for_it_epa: float
    conversion_prob: float
    sample_size: int
    low_sample: bool
    field_goal_available: bool
    recommendation: Option
    rule: str
    zone_curve: list[ZonePoint]
    simulated: bool
    warnings: list[str]
    context: dict[str, Any]


class CoachRequest(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    topic: Literal["matchup", "fourth_down"]
    home: str | None = Field(None, min_length=2, max_length=3)
    away: str | None = Field(None, min_length=2, max_length=3)
    season: int | None = None
    exclude_garbage_time: bool = True
    ydstogo: int | None = Field(None, ge=1, le=30, strict=True)
    yardline_100: int | None = Field(None, ge=1, le=99, strict=True)

    @model_validator(mode="after")
    def _topic_params(self):
        if self.topic == "matchup" and (not self.home or not self.away):
            raise ValueError("topic 'matchup' requiere home y away")
        if self.topic == "fourth_down" and (self.ydstogo is None or self.yardline_100 is None):
            raise ValueError("topic 'fourth_down' requiere ydstogo y yardline_100")
        return self


class CoachResponse(BaseModel):
    text: str
    ai_generated: bool
    source: Literal["ai_agent", "backend", "determinista"]
