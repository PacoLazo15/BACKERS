"""Lectura de los CSV de data/ (solo lectura) y armado del DataStore en memoria."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from backend import metrics

log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

PLAYS_COLS = ["season", "week", "posteam", "defteam", "down", "ydstogo", "yardline_100",
              "play_type", "pass_result", "yards_gained", "first_down", "epa", "cpoe", "garbage_time"]
TEAM_COLS = ["posteam", "season", "plays", "epa_per_play", "success_rate", "pass_epa", "run_epa",
             "cpoe", "early_down_pass_rate", "def_epa_per_play", "def_success_rate"]
META_COLS = ["team_abbr", "team_name", "team_conf", "team_division", "team_color", "team_color2"]
FOURTH_COLS = ["ydstogo", "field_zone", "go_for_it_epa", "conversion_prob", "sample_size"]

META_OUT = ["team_name", "team_conf", "team_division", "team_color", "team_color2"]
DEFAULT_COLOR = "#6B7280"

TEAMS = ["ARI", "ATL", "BAL", "BUF", "CAR", "CHI", "CIN", "CLE", "DAL", "DEN", "DET", "GB",
         "HOU", "IND", "JAX", "KC", "LA", "LAC", "LV", "MIA", "MIN", "NE", "NO", "NYG",
         "NYJ", "PHI", "PIT", "SEA", "SF", "TB", "TEN", "WAS"]


@dataclass
class DataStore:
    efficiency: dict[bool, pd.DataFrame]
    fourth_down: pd.DataFrame
    simulated: dict[str, bool] = field(default_factory=dict)

    @property
    def any_simulated(self) -> bool:
        return any(self.simulated.values())

    @property
    def seasons(self) -> list[int]:
        return sorted(int(s) for s in self.efficiency[True]["season"].unique())


def _read(path: Path, cols: list[str]) -> pd.DataFrame | None:
    """Devuelve el CSV con sus columnas usadas, o None si no existe o no cumple el contrato."""
    try:
        df = pd.read_csv(path)
    except Exception as exc:  # archivo ausente, vacío o ilegible
        log.warning("No se pudo leer %s: %s", path.name, type(exc).__name__)
        return None
    missing = [c for c in cols if c not in df.columns]
    if missing:
        log.warning("%s no tiene las columnas %s", path.name, missing)
        return None
    return df[cols].copy()


def _as_bool(s: pd.Series) -> pd.Series:
    if s.dtype == bool:
        return s
    return s.astype(str).str.strip().str.lower().isin(["true", "1", "t", "yes"])


def simulated_plays(seed: int = 2021, plays_per_team: int = 250) -> pd.DataFrame:
    """Jugadas sintéticas reproducibles con el esquema de plays_clean.csv."""
    rng = np.random.default_rng(seed)
    n = len(TEAMS) * plays_per_team
    posteam = np.repeat(TEAMS, plays_per_team)
    shift = rng.integers(1, len(TEAMS), n)
    defteam = np.array(TEAMS)[(np.repeat(np.arange(len(TEAMS)), plays_per_team) + shift) % len(TEAMS)]
    team_skill = dict(zip(TEAMS, rng.normal(0, 0.12, len(TEAMS))))
    result = rng.choice(["C", "I", "S", "IN", "R"], n, p=[0.56, 0.30, 0.065, 0.02, 0.055])
    epa = rng.normal(0, 1.4, n) + np.vectorize(team_skill.get)(posteam)
    yards = np.where(result == "C", rng.integers(0, 30, n),
                     np.where(result == "S", -rng.integers(1, 10, n),
                              np.where(result == "R", rng.integers(0, 15, n), 0)))
    down = rng.choice([1, 2, 3, 4], n, p=[0.36, 0.33, 0.28, 0.03])
    ydstogo = rng.integers(1, 15, n)
    return pd.DataFrame({
        "season": 2021,
        "week": rng.integers(1, 9, n),
        "posteam": posteam,
        "defteam": defteam,
        "down": down,
        "ydstogo": ydstogo,
        "yardline_100": rng.integers(1, 100, n),
        "play_type": np.where(result == "R", "run", "pass"),
        "pass_result": result,
        "yards_gained": yards,
        "first_down": (yards >= ydstogo).astype(int),
        "epa": epa.round(4),
        "cpoe": np.where(np.isin(result, ["C", "I", "IN"]), rng.normal(0, 40, n).round(4), np.nan),
        "garbage_time": rng.random(n) < 0.15,
    })


def _with_meta(eff: pd.DataFrame, meta: pd.DataFrame | None) -> pd.DataFrame:
    if meta is None:
        out = eff.copy()
        out["team_name"] = out["posteam"]
        out["team_conf"] = None
        out["team_division"] = None
        out["team_color"] = DEFAULT_COLOR
        out["team_color2"] = None
        return out
    m = meta.drop_duplicates("team_abbr").rename(columns={"team_abbr": "posteam"})
    out = eff.merge(m[["posteam", *META_OUT]], on="posteam", how="left")
    out["team_name"] = out["team_name"].fillna(out["posteam"])
    out["team_color"] = out["team_color"].fillna(DEFAULT_COLOR)
    return out


def _finish(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    num = df.select_dtypes("float").columns
    df[num] = df[num].round(4)
    df["season"] = df["season"].astype(int)
    df["plays"] = df["plays"].astype(int)
    return df.sort_values("posteam").reset_index(drop=True)


def load_store(data_dir: Path = DATA) -> DataStore:
    simulated: dict[str, bool] = {}
    sim_cache: dict[str, pd.DataFrame] = {}

    def sim() -> pd.DataFrame:
        if "plays" not in sim_cache:
            sim_cache["plays"] = simulated_plays()
        return sim_cache["plays"]

    plays = _read(data_dir / "plays_clean.csv", PLAYS_COLS)
    simulated["plays"] = plays is None
    if plays is None:
        plays = sim()
    plays["garbage_time"] = _as_bool(plays["garbage_time"])

    team = _read(data_dir / "team_efficiency.csv", TEAM_COLS)
    simulated["team_efficiency"] = team is None
    if team is None:
        team = metrics.team_metrics(sim(), exclude_garbage_time=True)

    meta = _read(data_dir / "teams_meta.csv", META_COLS)
    simulated["teams_meta"] = meta is None

    fourth = _read(data_dir / "fourth_down_situations.csv", FOURTH_COLS)
    simulated["fourth_down"] = fourth is None
    if fourth is None:
        fourth = metrics.fourth_down_from_plays(sim())
    fourth = fourth.dropna(subset=["ydstogo", "conversion_prob", "sample_size"]).copy()
    fourth["ydstogo"] = fourth["ydstogo"].astype(int)
    fourth["sample_size"] = fourth["sample_size"].astype(int)
    fourth["go_for_it_epa"] = fourth["go_for_it_epa"].fillna(0.0)

    eff_clean = team.merge(metrics.complementary_metrics(plays, True), on=metrics.KEYS, how="left")
    eff_all = metrics.team_metrics(plays, False).merge(
        metrics.complementary_metrics(plays, False), on=metrics.KEYS, how="left")

    return DataStore(
        efficiency={True: _finish(_with_meta(eff_clean, meta)), False: _finish(_with_meta(eff_all, meta))},
        fourth_down=fourth.reset_index(drop=True),
        simulated=simulated,
    )
