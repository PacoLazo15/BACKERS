"""Llamada a Amazon Bedrock (Nova) con boto3 y texto determinista de respaldo."""
from __future__ import annotations

import json
import logging
import os

import boto3
from botocore.config import Config

log = logging.getLogger(__name__)

OPTION_ES = {"go_for_it": "intentar la conversión", "field_goal": "patear gol de campo", "punt": "despejar"}

METRIC_ES = {
    "epa_per_play": "EPA/jugada", "success_rate": "tasa de éxito", "pass_epa": "EPA en pases",
    "run_epa": "EPA en scrambles", "cpoe": "CPOE", "def_epa_per_play": "EPA permitido/jugada",
}

SYSTEM_PROMPT = (
    "Eres un analista táctico de front office de la NFL. Responde en español, en 3 a 6 frases, "
    "sin listas ni encabezados. Usa únicamente los datos del JSON 'contexto' que recibes: no inventes "
    "estadísticas, jugadores, lesiones ni contexto externo. Si el dato que pide la pregunta no está en el "
    "contexto, dilo. Los datos son solo de jugadas de pase de las semanas 1-8 de 2021, por lo que no hay "
    "valores históricos de gol de campo ni de despeje. Advierte cuando una muestra sea pequeña."
)


def _client():
    region = os.environ.get("AWS_REGION", "us-east-1")
    config = Config(read_timeout=30, connect_timeout=5, retries={"max_attempts": 1})
    return boto3.client("bedrock-runtime", region_name=region, config=config)


def ask_bedrock(question: str, context: dict) -> str:
    """Devuelve el texto del modelo. Lanza excepción si Bedrock falla o responde vacío."""
    payload = json.dumps({"pregunta": question, "contexto": context}, ensure_ascii=False, default=str)
    response = _client().converse(
        modelId=os.environ.get("BEDROCK_MODEL_ID", "us.amazon.nova-pro-v1:0"),
        system=[{"text": SYSTEM_PROMPT}],
        messages=[{"role": "user", "content": [{"text": payload}]}],
        inferenceConfig={"maxTokens": 500, "temperature": 0.2},
    )
    parts = response["output"]["message"]["content"]
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        raise ValueError("respuesta vacía")
    return text


def _fourth_text(sim: dict) -> str:
    option = OPTION_ES.get(sim.get("recommendation"), sim.get("recommendation"))
    text = (
        f"4ta y {sim['ydstogo']} a {sim['yardline_100']} yardas de la zona de anotación. "
        f"Recomendación: {option}. {sim.get('rule', '')} "
        f"El EPA histórico de intentar en situaciones similares es {sim.get('go_for_it_epa', 0):+.2f}."
    )
    if sim.get("low_sample"):
        text += f" Ojo: la muestra es de solo {sim.get('sample_size')} jugadas."
    if not sim.get("exact_match", True):
        text += f" No hay datos exactos para 4ta y {sim['ydstogo']}; se usó 4ta y {sim.get('matched_ydstogo')}."
    return text


def _matchup_text(cmp: dict) -> str:
    parts = []
    for key in ("home_offense_vs_away_defense", "away_offense_vs_home_defense"):
        c = cmp.get(key) or {}
        if c:
            side = "favorece al ataque" if c.get("edge", 0) > 0 else "favorece a la defensa"
            parts.append(f"Ataque {c['offense_team']} vs defensa {c['defense_team']}: ventaja combinada "
                         f"{c.get('edge', 0):+.3f} EPA/jugada ({side}).")
    home = (cmp.get("home") or {}).get("posteam", "local")
    away = (cmp.get("away") or {}).get("posteam", "visitante")
    wins = {"home": [], "away": []}
    for m in cmp.get("primary", []):
        if m.get("better") in wins:
            wins[m["better"]].append(METRIC_ES.get(m["metric"], m["metric"]))
    if wins["home"]:
        parts.append(f"{home} es mejor en: {', '.join(wins['home'])}.")
    if wins["away"]:
        parts.append(f"{away} es mejor en: {', '.join(wins['away'])}.")
    return " ".join(parts) or "Sin datos suficientes para resumir el matchup."


def fallback_text(question: str, context: dict) -> str:
    """Resumen determinista construido solo con el contexto."""
    if context.get("tipo") == "fourth_down" and context.get("simulacion"):
        return _fourth_text(context["simulacion"])
    if context.get("tipo") == "matchup" and context.get("comparacion"):
        return _matchup_text(context["comparacion"])
    return "El copiloto no está disponible y no hay datos suficientes para una recomendación automática."
