"""
Sube las tablas curadas (.parquet) a s3://<S3_BUCKET_NAME>/curated/.

Uso (desde la raíz del proyecto, después de correr transform.py):
    python data_pipeline/upload_s3.py [carpeta_curated]

Lee las credenciales y el bucket del archivo .env (ver .env.example).
"""
import os
import sys
from pathlib import Path

import boto3
from dotenv import load_dotenv

TABLES = ["plays_clean", "team_efficiency", "fourth_down_situations", "teams_meta"]


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    load_dotenv(root / ".env")
    bucket = os.getenv("S3_BUCKET_NAME")
    if not bucket:
        sys.exit("Falta S3_BUCKET_NAME en .env")

    curated = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "curated"
    s3 = boto3.client("s3")
    for name in TABLES:
        path = curated / f"{name}.parquet"
        if not path.exists():
            sys.exit(f"No existe {path}. Corre primero: python data_pipeline/transform.py")
        key = f"curated/{name}.parquet"
        s3.upload_file(str(path), bucket, key)
        print(f"Subido: s3://{bucket}/{key}")


if __name__ == "__main__":
    main()
