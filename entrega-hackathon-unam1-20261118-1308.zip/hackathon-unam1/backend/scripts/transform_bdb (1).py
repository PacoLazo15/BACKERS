"""
Limpieza de datos NFL Big Data Bowl (temporada 2021, semanas 1-8, jugadas de pase)
enriquecidos con el play-by-play de nflverse (epa, wp, wpa, cpoe, air_yards, roof).

Las jugadas del Big Data Bowl se unen con nflverse por gameId = old_game_id y
playId = play_id. Los esquemas de salida siguen el contrato con la Persona B
(team_efficiency, fourth_down_situations, teams_meta), exportados en CSV.

Requisitos:
    pip install polars nflreadpy

Uso:
    python transform_bdb.py <carpeta_datos_bdb> <carpeta_salida>

    <carpeta_datos_bdb>  carpeta con games.csv y plays.csv del Big Data Bowl
    <carpeta_salida>     carpeta donde se escriben los CSV limpios

Salidas:
    plays_clean.csv              una fila por jugada válida, con métricas de nflverse
    team_efficiency.csv          eficiencia por equipo y temporada, sin tiempo basura
    fourth_down_situations.csv   resultados históricos en 4ta oportunidad
    teams_meta.csv               nombres, conferencias, colores y logos
"""
import sys
from pathlib import Path

import nflreadpy as nfl
import polars as pl

SEASON = 2021
WP_MIN, WP_MAX = 0.05, 0.95

NFLVERSE_COLUMNS = [
    "game_id", "play_id", "old_game_id", "season", "week", "posteam", "defteam",
    "down", "ydstogo", "yardline_100", "qtr", "game_seconds_remaining",
    "score_differential", "play_type", "yards_gained", "first_down",
    "epa", "wp", "wpa", "cpoe", "air_yards", "roof",
]

TEAMS_COLUMNS = [
    "team_abbr", "team_name", "team_conf", "team_division",
    "team_color", "team_color2", "team_logo_espn",
]


def load_nflverse_pbp() -> pl.DataFrame:
    pbp = nfl.load_pbp([SEASON]).select(NFLVERSE_COLUMNS)
    return pbp.with_columns(
        pl.col("old_game_id").cast(pl.Int64).alias("bdb_game_id"),
        pl.col("play_id").cast(pl.Int64),
    )


def build_plays_clean(bdb_dir: Path, pbp: pl.DataFrame) -> pl.DataFrame:
    bdb = pl.read_csv(bdb_dir / "plays.csv", null_values="NA", infer_schema_length=10000)
    bdb = bdb.select(
        pl.col("gameId").cast(pl.Int64).alias("bdb_game_id"),
        pl.col("playId").cast(pl.Int64).alias("play_id"),
        pl.col("passResult").alias("pass_result"),
        pl.col("offenseFormation").alias("offense_formation"),
        pl.col("pff_passCoverage").alias("pass_coverage"),
        pl.col("pff_passCoverageType").alias("pass_coverage_type"),
    )

    plays = bdb.join(pbp, on=["bdb_game_id", "play_id"], how="inner")

    # Jugadas reales de pase/acarreo: quita jugadas anuladas (no_play) y conversiones de 2 pts
    plays = plays.filter(
        pl.col("play_type").is_in(["pass", "run"])
        & pl.col("down").is_not_null()
        & pl.col("epa").is_not_null()
    )

    garbage_time = ~pl.col("wp").is_between(WP_MIN, WP_MAX)

    return (
        plays.select(
            pl.col("bdb_game_id").alias("game_id"),
            pl.col("game_id").alias("nflverse_game_id"),
            "play_id",
            pl.col("season").cast(pl.Int64),
            pl.col("week").cast(pl.Int64),
            "posteam",
            "defteam",
            pl.col("down").cast(pl.Int64),
            pl.col("ydstogo").cast(pl.Int64),
            pl.col("yardline_100").cast(pl.Int64),
            pl.col("qtr").cast(pl.Int64),
            pl.col("game_seconds_remaining").cast(pl.Int64),
            pl.col("score_differential").cast(pl.Int64),
            "play_type",
            "pass_result",
            pl.col("yards_gained").cast(pl.Int64),
            pl.col("first_down").cast(pl.Int64),
            "epa",
            "wp",
            "wpa",
            "cpoe",
            "air_yards",
            "roof",
            "offense_formation",
            "pass_coverage",
            "pass_coverage_type",
            garbage_time.alias("garbage_time"),
        )
        .sort("game_id", "play_id")
    )


def build_team_efficiency(plays: pl.DataFrame, teams: pl.DataFrame) -> pl.DataFrame:
    clean = plays.filter(~pl.col("garbage_time"))

    offense = clean.group_by("posteam", "season").agg(
        pl.len().cast(pl.Int64).alias("plays"),
        pl.col("epa").mean().alias("epa_per_play"),
        (pl.col("epa") > 0).mean().alias("success_rate"),
        pl.col("epa").filter(pl.col("play_type") == "pass").mean().alias("pass_epa"),
        pl.col("epa").filter(pl.col("play_type") == "run").mean().alias("run_epa"),
        pl.col("cpoe").filter(pl.col("play_type") == "pass").mean().alias("cpoe"),
        (pl.col("play_type") == "pass")
        .filter(pl.col("down").is_in([1, 2]))
        .mean()
        .alias("early_down_pass_rate"),
    )
    defense = (
        clean.group_by("defteam", "season")
        .agg(
            pl.col("epa").mean().alias("def_epa_per_play"),
            (pl.col("epa") > 0).mean().alias("def_success_rate"),
        )
        .rename({"defteam": "posteam"})
    )
    return (
        offense.join(defense, on=["posteam", "season"], how="left")
        .join(
            teams.select("team_abbr", "team_logo_espn", "team_color"),
            left_on="posteam",
            right_on="team_abbr",
            how="left",
        )
        .sort(["season", "epa_per_play"], descending=[True, True])
    )


def build_fourth_down(plays: pl.DataFrame) -> pl.DataFrame:
    field_zone = (
        pl.when(pl.col("yardline_100") <= 20)
        .then(pl.lit("RedZone (1-20)"))
        .when(pl.col("yardline_100") <= 50)
        .then(pl.lit("Opponent Territory (21-50)"))
        .otherwise(pl.lit("Own Territory (51-99)"))
    )
    return (
        plays.filter(pl.col("down") == 4, pl.col("ydstogo").is_between(1, 10))
        .with_columns(field_zone.alias("field_zone"))
        .group_by("ydstogo", "field_zone")
        .agg(
            pl.col("epa").mean().alias("go_for_it_epa"),
            pl.col("first_down").mean().alias("conversion_prob"),
            pl.len().cast(pl.Int64).alias("sample_size"),
        )
        # El Big Data Bowl solo trae pases: no hay goles de campo ni despejes.
        # Las columnas se conservan vacías para respetar el contrato con la Persona B.
        .with_columns(
            pl.lit(None, dtype=pl.Float64).alias("fg_epa"),
            pl.lit(None, dtype=pl.Float64).alias("fg_make_prob"),
            pl.lit(None, dtype=pl.Float64).alias("punt_epa"),
        )
        .select(
            "ydstogo", "field_zone", "go_for_it_epa", "conversion_prob",
            "fg_epa", "fg_make_prob", "punt_epa", "sample_size",
        )
        .sort("field_zone", "ydstogo")
    )


def main() -> None:
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    bdb_dir, out_dir = Path(sys.argv[1]), Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Descargando play-by-play {SEASON} y equipos de nflverse...")
    pbp = load_nflverse_pbp()
    teams = nfl.load_teams().select(TEAMS_COLUMNS)

    plays = build_plays_clean(bdb_dir, pbp)
    team_eff = build_team_efficiency(plays, teams)
    fourth = build_fourth_down(plays)

    plays.write_csv(out_dir / "plays_clean.csv", float_precision=4)
    team_eff.write_csv(out_dir / "team_efficiency.csv", float_precision=4)
    fourth.write_csv(out_dir / "fourth_down_situations.csv", float_precision=4)
    teams.write_csv(out_dir / "teams_meta.csv")

    print(f"plays_clean.csv: {plays.height} filas ({plays['garbage_time'].sum()} en tiempo basura)")
    print(f"team_efficiency.csv: {team_eff.height} filas")
    print(f"fourth_down_situations.csv: {fourth.height} filas")
    print(f"teams_meta.csv: {teams.height} filas")


if __name__ == "__main__":
    main()
