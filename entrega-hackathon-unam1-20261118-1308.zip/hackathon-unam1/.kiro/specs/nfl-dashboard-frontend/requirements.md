# Requirements Document

## Introduction

Este documento especifica el módulo de dashboard del Copiloto de Estrategia de Front Office de la NFL. El módulo muestra un cuadrante de eficiencia ofensiva contra defensiva con filtro de tiempo basura, una comparación de enfrentamientos (Matchups) y un simulador de 4ta oportunidad, con un copiloto táctico en Amazon Bedrock que solo se consulta a petición del usuario.

**Stack.** Se respeta `rules.md`:

- La interfaz se implementa en `dashboard/` (React + TypeScript + Tailwind 3 + Recharts). No se usa Streamlit.
- La API se implementa en `backend/` (FastAPI) bajo `/api/...`.
- Los datos se leen con pandas desde los CSV de `data/`, que son de solo lectura.
- La lógica de contexto y el agente de Bedrock del equipo viven en `ai_agent/bedrock_coach.py`. La API los importa a través de un adaptador en `backend/` y tiene un respaldo local con las mismas firmas para cuando `ai_agent/` o `.env` no estén presentes.
- `backend/scripts/` es el pipeline que genera los CSV fuera de la app. La app no lo importa ni lo ejecuta, y no usa S3.

**Origen de los datos.** Big Data Bowl 2021 (semanas 1-8, jugadas de pase y scrambles del QB) unido al play-by-play de nflverse. Las jugadas con `play_type == "run"` son scrambles (`pass_result == "R"`).

## Glossary

- **Dashboard**: Aplicación React ubicada en `dashboard/`.
- **API**: Servicio FastAPI ubicado en `backend/` que expone los endpoints bajo `/api/...`.
- **Data_Loader**: Componente de la API que lee los CSV de `data/` con pandas.
- **Plays_Clean**: `data/plays_clean.csv`. Columnas usadas: `season`, `week`, `posteam`, `defteam`, `down`, `ydstogo`, `yardline_100`, `play_type`, `pass_result`, `yards_gained`, `first_down`, `epa`, `cpoe`, `garbage_time`.
- **Team_Efficiency**: `data/team_efficiency.csv`, una fila por equipo y temporada, sin Tiempo_Basura. Columnas usadas: `posteam`, `season`, `plays`, `epa_per_play`, `success_rate`, `pass_epa`, `run_epa`, `cpoe`, `early_down_pass_rate`, `def_epa_per_play`, `def_success_rate`.
- **Teams_Meta**: `data/teams_meta.csv`. Columnas usadas: `team_abbr`, `team_name`, `team_conf`, `team_division`, `team_color`, `team_color2`. `team_logo_espn` no se usa.
- **Fourth_Down_Situations**: `data/fourth_down_situations.csv`. Columnas usadas: `ydstogo` (1-10), `field_zone`, `go_for_it_epa`, `conversion_prob`, `sample_size`. `fg_epa`, `fg_make_prob` y `punt_epa` vienen vacías.
- **Field_Zone**: 1-20 `RedZone (1-20)`, 21-50 `Opponent Territory (21-50)`, 51-99 `Own Territory (51-99)`.
- **EPA**: Puntos esperados añadidos por jugada.
- **Tiempo_Basura**: Jugadas con `garbage_time` verdadero (probabilidad de victoria fuera de 0.05-0.95).
- **Metricas_Principales**: `epa_per_play`, `def_epa_per_play`, `success_rate`, `pass_epa`, `run_epa`, `cpoe`.
- **Metricas_Complementarias**: Calculadas desde Plays_Clean por `posteam`: `yards_per_play` (media de `yards_gained`), `completion_pct` (C / (C + I + IN)) y `sack_rate` (S / jugadas).
- **Bedrock_Coach**: Módulo `ai_agent/bedrock_coach.py` con `list_teams()`, `get_matchup_context(team_a, team_b)`, `get_fourth_down_context(ydstogo, yardline_100)` y `ask_front_office_coach(question, context)`.
- **Coach_Adapter**: Componente de la API que importa Bedrock_Coach y, si no está disponible o falla, usa el Respaldo_Local.
- **Respaldo_Local**: Implementación en `backend/` de las cuatro funciones de Bedrock_Coach, con las mismas firmas, calculada con los datos del Data_Loader.
- **Contexto_Matchup**: Resultado de `get_matchup_context`: métricas, rankings (`*_rank`) y promedios de la liga.
- **Contexto_4th_Down**: Resultado de `get_fourth_down_context`: escenario exacto, distancias cercanas y lista `warnings`.
- **Regla_4th_Down**: (1) `go_for_it` si `conversion_prob >= 0.50` y `sample_size >= 5`; (2) si no, `field_goal` si `yardline_100 <= 37`; (3) si no, `punt`.
- **Copiloto**: Función `ask_front_office_coach` invocada a través del Coach_Adapter.
- **Datos_Simulados**: Datos de respaldo con el mismo esquema que los CSV, usados cuando un CSV no está disponible o no cumple su contrato.

## Requirements

### Requirement 1: Carga de datos y contrato de la API

**User Story:** Como analista de front office, quiero que el Dashboard obtenga los datos desde la API, para que las vistas siempre muestren información coherente con el contrato de datos.

#### Acceptance Criteria

1. WHEN la API arranca, THE Data_Loader SHALL leer Plays_Clean, Team_Efficiency, Teams_Meta y Fourth_Down_Situations con pandas.
2. THE API SHALL exponer `GET /health` que responde `{"status": "ok"}`.
3. THE API SHALL exponer todos sus endpoints de datos bajo el prefijo `/api/`.
4. THE Dashboard SHALL invocar la API con rutas relativas sin diagonal inicial, con la forma `api/<ruta>`.
5. IF un CSV no existe o no contiene todas las columnas usadas de su contrato, THEN THE Data_Loader SHALL usar Datos_Simulados para ese dataset.
6. WHILE la API usa Datos_Simulados, THE Dashboard SHALL mostrar un aviso visible que indique el uso de datos simulados.
7. THE Data_Loader SHALL tratar los archivos de `data/` como de solo lectura.
8. THE API SHALL calcular los datos en memoria al arrancar o al responder, sin escribir archivos en disco.
9. FOR ALL registros de eficiencia por equipo, serializar a JSON y deserializar SHALL producir valores equivalentes (propiedad de ida y vuelta).
10. THE API SHALL incluir en cada equipo `team_name`, `team_color` y `team_color2` de Teams_Meta, y SHALL omitir `team_logo_espn`.
11. THE API SHALL obtener la lista de equipos del selector con `list_teams()` a través del Coach_Adapter, enriquecida con Teams_Meta.

### Requirement 2: Integración con Bedrock_Coach

**User Story:** Como integrante del equipo, quiero que la API use la lógica de `ai_agent/bedrock_coach.py`, para que el dashboard y el agente compartan el mismo contexto.

#### Acceptance Criteria

1. WHEN la API arranca, THE Coach_Adapter SHALL intentar importar Bedrock_Coach después de ejecutar `cargar_env()`.
2. IF Bedrock_Coach no existe, no se puede importar o le falta alguna de sus cuatro funciones, THEN THE Coach_Adapter SHALL usar el Respaldo_Local para las cuatro funciones.
3. IF una función de Bedrock_Coach lanza una excepción distinta de `ValueError`, THEN THE Coach_Adapter SHALL usar la función equivalente del Respaldo_Local para esa llamada.
4. WHEN `get_matchup_context` lanza `ValueError`, THE API SHALL responder con código 404 y un mensaje que nombre al equipo sin datos.
5. THE API SHALL convertir los resultados de Bedrock_Coach a JSON válido, reemplazando `NaN` por `null` y los tipos de numpy por tipos nativos.
6. THE API SHALL exponer `GET /api/meta` con el origen del contexto (`ai_agent` o `backend`) para que el Dashboard lo muestre.

### Requirement 3: Cuadrante de eficiencia ofensiva contra defensiva

**User Story:** Como analista de front office, quiero ver un cuadrante de eficiencia ofensiva contra defensiva sin tiempo basura, para que pueda clasificar a los equipos según su rendimiento real.

#### Acceptance Criteria

1. THE API SHALL exponer `GET /api/efficiency` que acepta `season` y `exclude_garbage_time` y devuelve una fila por equipo con Metricas_Principales y Metricas_Complementarias.
2. WHEN `exclude_garbage_time` es verdadero, THE API SHALL devolver las Metricas_Principales de Team_Efficiency y las Metricas_Complementarias calculadas desde Plays_Clean sin Tiempo_Basura.
3. WHEN `exclude_garbage_time` es falso, THE API SHALL calcular todas las métricas desde todas las jugadas de Plays_Clean, con las mismas fórmulas que generan Team_Efficiency.
4. THE Dashboard SHALL mostrar un punto por equipo de la temporada seleccionada, con el color `team_color` del equipo.
5. THE Dashboard SHALL tener el filtro de Tiempo_Basura activado por defecto.
6. WHEN el usuario cambia el filtro de Tiempo_Basura, THE Dashboard SHALL actualizar el cuadrante en un máximo de 2 segundos.
7. THE Dashboard SHALL dividir el cuadrante con las medianas de `epa_per_play` y `def_epa_per_play` de los equipos mostrados.
8. THE Dashboard SHALL mostrar el eje de `def_epa_per_play` invertido, de modo que un valor menor quede arriba.
9. THE Dashboard SHALL etiquetar cada cuadrante con un nombre que describa la combinación de ataque y defensa.
10. WHEN el usuario pasa el cursor sobre un punto, THE Dashboard SHALL mostrar `team_name`, `plays`, `epa_per_play`, `def_epa_per_play`, `success_rate`, `yards_per_play`, `completion_pct` y `sack_rate`.
11. IF no existen filas para la selección, THEN THE Dashboard SHALL mostrar el mensaje "Sin datos para la selección".
12. FOR ALL equipos, el recálculo sin Tiempo_Basura desde Plays_Clean SHALL coincidir con Team_Efficiency con una tolerancia de 1e-4 (propiedad de consistencia).

### Requirement 4: Comparación de Matchups

**User Story:** Como estratega, quiero comparar dos equipos en un Matchup, para que pueda identificar ventajas y desventajas antes de un partido.

#### Acceptance Criteria

1. THE API SHALL exponer `GET /api/matchup` que acepta `home`, `away`, `season` y `exclude_garbage_time`, y devuelve la comparación y el Contexto_Matchup.
2. THE Dashboard SHALL mostrar lado a lado las Metricas_Principales de ambos equipos y, en una sección de detalle, las Metricas_Complementarias.
3. THE Dashboard SHALL mostrar la diferencia numérica (local menos visitante) para cada métrica.
4. THE Dashboard SHALL resaltar en cada métrica al equipo con el mejor valor, donde un valor menor es mejor para `def_epa_per_play` y `sack_rate`.
5. THE Dashboard SHALL mostrar una comparación de ataque local contra defensa visitante y viceversa, basada en `epa_per_play` y `def_epa_per_play`.
6. WHEN el Contexto_Matchup contiene campos `*_rank`, THE Dashboard SHALL mostrar el ranking de liga de cada equipo junto a la métrica correspondiente.
7. IF el usuario selecciona el mismo equipo como local y visitante, THEN THE Dashboard SHALL mostrar "Selecciona dos equipos distintos" y no solicitar la comparación.
8. IF alguno de los equipos no tiene datos, THEN THE API SHALL responder con código 404 y un mensaje que nombre al equipo sin datos.
9. FOR ALL pares de equipos A y B, la diferencia de una métrica en (A, B) SHALL ser igual a la negación de la diferencia en (B, A) (propiedad de simetría).

### Requirement 5: Simulador de 4ta oportunidad

**User Story:** Como coordinador ofensivo, quiero simular una situación de 4ta oportunidad, para que pueda decidir entre intentar, patear gol de campo o despejar con una regla transparente.

#### Acceptance Criteria

1. THE API SHALL exponer `POST /api/fourth-down/simulate` que recibe `ydstogo` y `yardline_100` y devuelve `field_zone`, `go_for_it_epa`, `conversion_prob`, `sample_size`, la recomendación, el texto de la regla, la lista `warnings` y el Contexto_4th_Down.
2. THE Dashboard SHALL ofrecer controles para `ydstogo` (enteros 1-30) y `yardline_100` (enteros 1-99).
3. WHEN el usuario modifica un control, THE Dashboard SHALL mostrar el resultado en un máximo de 2 segundos.
4. THE API SHALL usar la fila de la Field_Zone de `yardline_100` con el `ydstogo` más cercano, con empate al menor, y SHALL buscar en todas las zonas si la zona no tiene filas.
5. THE API SHALL indicar el `ydstogo` de la fila usada y si coincide exactamente con el solicitado.
6. THE API SHALL recomendar según la Regla_4th_Down.
7. THE Dashboard SHALL mostrar la recomendación, la regla aplicada, `conversion_prob` como porcentaje con un decimal, `go_for_it_epa` y `sample_size` siempre visible.
8. THE Dashboard SHALL mostrar las tres opciones; para `field_goal` y `punt` SHALL mostrar "Sin datos" como valor esperado, porque Fourth_Down_Situations no tiene valores para ellas.
9. THE Dashboard SHALL mostrar cada elemento de `warnings`; THE API SHALL incluir una advertencia cuando `sample_size` es menor que 5.
10. THE Dashboard SHALL mostrar en un gráfico de barras `conversion_prob` por `ydstogo` de la Field_Zone, con la fila usada resaltada.
11. IF `ydstogo` o `yardline_100` están fuera de rango o no son enteros, THEN THE API SHALL responder con código 422 y la descripción del campo inválido.
12. FOR ALL situaciones válidas, la recomendación SHALL cumplir la Regla_4th_Down (propiedad de invariante).

### Requirement 6: Copiloto táctico bajo demanda

**User Story:** Como coordinador ofensivo, quiero preguntarle al copiloto sobre un matchup o una 4ta oportunidad, para que pueda justificar la decisión ante el cuerpo técnico sin gastar créditos de más.

#### Acceptance Criteria

1. THE API SHALL exponer `POST /api/coach/ask` que recibe `question`, `topic` (`matchup` o `fourth_down`) y los parámetros del tema, y devuelve el texto, si fue generado por IA y el origen.
2. THE API SHALL construir el contexto en el servidor con `get_matchup_context` o `get_fourth_down_context` (y la simulación con la Regla_4th_Down) y SHALL pasarlo a `ask_front_office_coach`. THE API SHALL ignorar cualquier contexto enviado por el cliente.
3. THE Dashboard SHALL invocar `POST /api/coach/ask` solo cuando el usuario presione el botón de consultar; ninguna carga de página, cambio de filtro o cambio de control SHALL invocarlo.
4. THE API SHALL limitar `question` a entre 1 y 500 caracteres y responder 422 fuera de ese rango.
5. WHEN Bedrock_Coach no está disponible, THE Respaldo_Local SHALL llamar a Amazon Bedrock con `boto3.client("bedrock-runtime", region_name=region)`, el modelo de `BEDROCK_MODEL_ID` o `us.amazon.nova-pro-v1:0`, y la región de `AWS_REGION` o `us-east-1`.
6. THE API SHALL cargar `.env` con la función `cargar_env` de `rules.md` antes de usar boto3 o importar Bedrock_Coach, y SHALL obtener las credenciales del entorno sin leerlas, validarlas ni registrarlas.
7. IF el Copiloto no responde en 30 segundos o lanza un error, THEN THE API SHALL responder con un texto determinista construido a partir del contexto e indicar que no es generado por IA.
8. WHILE el Copiloto procesa la solicitud, THE Dashboard SHALL mostrar un indicador de carga y deshabilitar el botón.
9. WHEN la IA no está disponible, THE Dashboard SHALL seguir mostrando el cuadrante, los Matchups y la simulación completos.
10. THE Respaldo_Local SHALL instruir al modelo a basar su texto únicamente en el contexto que recibe.
11. THE Dashboard SHALL etiquetar el texto como "Generado por IA" cuando lo sea, y como "Recomendación automática (sin IA)" en otro caso.

### Requirement 7: Estructura, estilo y despliegue

**User Story:** Como integrante del equipo, quiero que el módulo respete el contrato de despliegue, para que AWS pueda hospedarlo sin cambios.

#### Acceptance Criteria

1. THE Dashboard SHALL generar su build con `vite build` en `dashboard/dist`.
2. THE API SHALL servir `dashboard/dist` y los endpoints `/api/...` en la misma URL y puerto.
3. THE Dashboard SHALL configurar en `vite.config.ts` `base: './'` y un proxy de `/api` hacia `http://localhost:8000`.
4. THE Dashboard SHALL usar Tailwind CSS 3.4 sin la sintaxis de Tailwind 4.
5. THE módulo SHALL usar únicamente las dependencias y versiones fijadas en `rules.md`.
6. THE Dashboard SHALL usar rutas relativas sin diagonal inicial para imágenes, hojas de estilo y enlaces.
7. THE Dashboard SHALL evitar `localhost`, `127.0.0.1` y URLs absolutas en el código del cliente, incluidas las URLs de logos de Teams_Meta.
8. THE módulo SHALL dejar sin modificar `ai_agent/`, `backend/scripts/` y los archivos de `data/`.
9. THE Dashboard SHALL presentar su interfaz en español.
10. THE Dashboard SHALL adaptar su diseño a anchos de pantalla desde 1024 píxeles.
