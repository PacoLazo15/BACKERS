﻿# Implementation Plan

Las tareas 1-3 y 6-8 (datos, métricas, matchup, 4th down, API base, cuadrante) ya están implementadas y probadas. Este plan cubre la integración con `ai_agent/bedrock_coach.py`.

- [x] 1. Datos y métricas (`data_loader.py`, `metrics.py`)
  - _Requirements: 1.1-1.10, 3.1-3.3, 3.12, 4.9, 5.4-5.6, 5.12_

- [ ] 2. Adaptador del copiloto
  - [ ] 2.1 Crear `backend/coach_local.py` con `LocalCoach`: `list_teams`, `get_matchup_context` (métricas, `*_rank`, `league_avg`, `ValueError`), `get_fourth_down_context` (`situation`, `exact`, `nearby`, `warnings`) y `ask`
    - _Requirements: 2.2, 4.6, 5.9, 6.5, 6.10_
  - [ ] 2.2 Reescribir `backend/advisor.py` con `ask_bedrock(question, context)` y `fallback_text(question, context)` para ambos temas
    - _Requirements: 6.5, 6.6, 6.7, 6.10_
  - [ ] 2.3 Crear `backend/coach.py` con `load_external`, `Coach` y `to_jsonable`; timeout de 30 s en `ask`
    - _Requirements: 2.1, 2.2, 2.3, 2.5, 6.7_
  - [ ] 2.4 Pruebas `tests/test_coach.py`: módulo falso que falla, que lanza `ValueError`, incompleto, lento; `to_jsonable`
    - _Requirements: 2.2, 2.3, 2.5, 6.7_

- [ ] 3. Endpoints
  - [ ] 3.1 `schemas.py`: `coach_source`, `context`, `warnings`, `CoachRequest`, `CoachResponse`
    - _Requirements: 2.6, 4.1, 5.1, 6.1, 6.4_
  - [ ] 3.2 `main.py`: crear `Coach` en el `lifespan`; `/api/meta` con `list_teams`; `context` en `/api/matchup` (404 con `ValueError`); `warnings` y `context` en `/api/fourth-down/simulate`; `POST /api/coach/ask` con contexto construido en el servidor; quitar `/api/fourth-down/advice`
    - _Requirements: 1.11, 2.4, 2.6, 4.1, 4.8, 5.1, 6.1, 6.2, 6.3_
  - [ ] 3.3 Actualizar `tests/test_api.py` y `tests/test_advisor.py`; prueba de que ningún otro endpoint invoca el copiloto (Propiedad 8)
    - _Requirements: 6.2, 6.3, 6.4, 6.7_

- [ ] 4. Checkpoint backend: `pytest` en verde

- [ ] 5. Dashboard
  - [ ] 5.1 `types.ts` y `api.ts`: `coach_source`, `context`, `warnings`, `api.ask`
    - _Requirements: 1.4, 6.1_
  - [ ] 5.2 `components/CoachPanel.tsx` (reemplaza `AdvicePanel.tsx`): pregunta editable, consulta solo al presionar el botón, spinner, etiqueta
    - _Requirements: 6.3, 6.8, 6.9, 6.11_
  - [ ] 5.3 `MatchupPanel.tsx`: rankings `#n` desde `context` y CoachPanel de matchup
    - _Requirements: 4.6, 6.1_
  - [ ] 5.4 `FourthDownSimulator.tsx`: tabla de tres opciones con "Sin datos", lista de `warnings` y CoachPanel de 4th down
    - _Requirements: 5.7, 5.8, 5.9_
  - [ ] 5.5 `App.tsx`: mostrar el origen del contexto
    - _Requirements: 2.6_

- [ ] 6. Verificación final
  - [ ] 6.1 `tsc`, `vite build` y búsqueda de `'/api`, `localhost`, `127.0.0.1` y `http` en `dashboard/src`
    - _Requirements: 7.1, 7.5, 7.6, 7.7_
  - [ ] 6.2 Uvicorn: `/`, `/health`, `/api/*` en un puerto; `.\.hackathon\setup.cmd --check`
    - _Requirements: 7.2_
