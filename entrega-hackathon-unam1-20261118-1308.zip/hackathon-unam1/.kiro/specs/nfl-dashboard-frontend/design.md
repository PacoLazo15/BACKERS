# Design Document

## Overview

FastAPI (`backend/`) lee los cuatro CSV de `data/` con pandas al arrancar, calcula las métricas en memoria y las expone bajo `/api/...`. Un adaptador (`backend/coach.py`) importa `ai_agent/bedrock_coach.py` si existe y, si no, o si una llamada falla, usa un respaldo local con las mismas firmas. El dashboard React + Vite + Recharts (`dashboard/`) consume la API con rutas relativas `api/<ruta>`, y FastAPI sirve `dashboard/dist` en el mismo puerto.

## Datos (inspeccionados)

| Archivo | Filas | Uso |
|---|---|---|
| `plays_clean.csv` | 8,034 (1,316 con `garbage_time`) | Recálculo con y sin tiempo basura; Metricas_Complementarias |
| `team_efficiency.csv` | 32 (2021) | Metricas_Principales sin tiempo basura |
| `teams_meta.csv` | 36 (incluye OAK, SD, STL, LAR) | Nombre, conferencia, división, colores |
| `fourth_down_situations.csv` | 26 de 30 combinaciones `ydstogo × field_zone` | Simulador. `fg_epa`, `fg_make_prob`, `punt_epa` vacías |

Fórmulas (las de `backend/scripts/transform_bdb (1).py`; el recálculo sin tiempo basura coincide con `team_efficiency.csv` con error máximo de 5e-5):

| Métrica | Fórmula sobre `plays_clean` |
|---|---|
| `plays` | jugadas por `posteam` |
| `epa_per_play` / `def_epa_per_play` | media de `epa` por `posteam` / `defteam` |
| `success_rate` / `def_success_rate` | proporción de `epa > 0` por `posteam` / `defteam` |
| `pass_epa`, `run_epa` | media de `epa` con `play_type` `pass` / `run` (scrambles) |
| `cpoe` | media de `cpoe` en pases (ignora nulos) |
| `early_down_pass_rate` | proporción de pases en `down ∈ {1, 2}` |
| `yards_per_play` | media de `yards_gained` |
| `completion_pct` | `count(C) / count(C, I, IN)` |
| `sack_rate` | `count(S) / plays` |

## Architecture

```mermaid
flowchart LR
  subgraph data/ [data/ solo lectura]
    CSV[4 CSV]
  end
  subgraph ai_agent/ [ai_agent/ del equipo, opcional]
    BC[bedrock_coach.py]
  end
  subgraph backend/
    DL[data_loader.py]
    MET[metrics.py]
    CO[coach.py<br/>adaptador]
    LF[coach_local.py<br/>respaldo local]
    AD[advisor.py<br/>Bedrock Converse]
    API[main.py]
  end
  CSV --> DL --> MET --> API
  BC -. "import si existe" .-> CO
  LF --> CO --> API
  DL --> LF
  AD --> LF
  API -- "fetch('api/...')" --> UI[dashboard React]
```

- `main.py` ejecuta `cargar_env()` como primera instrucción y solo después importa `coach.py`, que importa `ai_agent.bedrock_coach` (2.1, 6.6).
- Todo el cálculo de datos ocurre en el `lifespan`. Ningún módulo escribe en disco.
- La IA solo se invoca desde `POST /api/coach/ask` (6.3).

## Components and Interfaces

```
backend/
  main.py          # cargar_env(), app, rutas, estáticos
  data_loader.py   # DataStore, lectura, validación, Datos_Simulados
  metrics.py       # funciones puras: métricas, matchup, 4th down
  coach.py         # Coach: adaptador ai_agent -> respaldo local, JSON seguro, timeout
  coach_local.py   # LocalCoach: las 4 funciones de bedrock_coach con los datos del DataStore
  advisor.py       # llamada Bedrock Converse con boto3 y texto determinista
  schemas.py       # modelos Pydantic
tests/
  test_metrics.py, test_api.py, test_advisor.py, test_coach.py
```

### `coach.py` (Coach_Adapter)

```python
REQUIRED = ("list_teams", "get_matchup_context", "get_fourth_down_context", "ask_front_office_coach")

def load_external():                       # -> módulo o None
    try:
        mod = importlib.import_module("ai_agent.bedrock_coach")
    except Exception:                      # ImportError, error al importar por falta de .env, etc.
        return None
    return mod if all(callable(getattr(mod, n, None)) for n in REQUIRED) else None

class Coach:
    def __init__(self, local: LocalCoach, external=None, ask_timeout: float = 30)
    source: Literal["ai_agent", "backend"]
    def list_teams(self) -> list[str]
    def get_matchup_context(self, a, b) -> dict          # ValueError se propaga (-> 404)
    def get_fourth_down_context(self, ydstogo, yl) -> dict
    def ask(self, question, context) -> {"text", "ai_generated", "source"}
```

- Cada llamada al módulo externo va en `try`; cualquier excepción distinta de `ValueError` registra el tipo y usa `LocalCoach` (2.3).
- `ask`: ejecuta `ask_front_office_coach` en un `ThreadPoolExecutor` con `future.result(timeout=30)`. Si devuelve `str` no vacío o `dict` con `text`/`answer`/`response`, es `ai_generated: True`. Error, timeout o vacío → texto determinista directamente, sin una segunda llamada a Bedrock para no gastar créditos dos veces (6.7). Sin módulo externo → `LocalCoach.ask` (Bedrock con boto3 y, si falla, texto determinista).
- El `context` que recibe `ask_front_office_coach` es `{"tipo", "simulacion" | "comparacion", "contexto": <resultado de get_*_context>}`.
- `to_jsonable(obj)`: convierte recursivamente numpy a nativos, `NaN`/`inf` a `None`, `DataFrame`/`Series` a registros, tuplas a listas (2.5).
- `list_teams` del módulo externo se intersecta con los equipos del DataStore; si la intersección queda vacía, se usa la lista local.

### `coach_local.py` (Respaldo_Local)

Mismas firmas que `bedrock_coach.py`, usando `store.efficiency[True]` y `store.fourth_down`:

- `list_teams()` → abreviaturas ordenadas.
- `get_matchup_context(a, b)` → `{"team_a": {...métricas, *_rank}, "team_b": {...}, "league_avg": {...}}`. `*_rank` es 1 = mejor de la liga, invirtiendo el orden en `def_epa_per_play` y `sack_rate`. `ValueError("Sin datos para el equipo X")` si no existe.
- `get_fourth_down_context(ydstogo, yl)` → `{"situation", "exact" (fila o None), "nearby" (filas de la zona con |Δydstogo| ≤ 2), "warnings": [...]}`. Advertencias: muestra < 5, sin fila exacta, `ydstogo > 10` fuera del rango de datos, y que no hay datos de gol de campo ni despeje.
- `ask(question, context)` → `advisor.ask_bedrock(question, context)`; si falla, `advisor.fallback_text(context)`.

### `advisor.py`

- `ask_bedrock(question, context) -> str`: `boto3.client("bedrock-runtime", region_name=os.environ.get("AWS_REGION", "us-east-1"), config=Config(read_timeout=30, connect_timeout=5, retries={"max_attempts": 1}))` y `converse(modelId=os.environ.get("BEDROCK_MODEL_ID", "us.amazon.nova-pro-v1:0"), ...)`. Sin acceso a credenciales en el código. El prompt de sistema exige español, 3-6 frases y usar solo el JSON recibido (6.5, 6.10).
- `fallback_text(question, context) -> str`: resumen determinista. Para 4th down usa la recomendación y la regla de la simulación; para matchup, la ventaja combinada de cada cruce y el mejor equipo en cada métrica principal.

### `metrics.py`

Sin cambios de comportamiento: `team_metrics`, `complementary_metrics`, `matchup`, `field_zone`, `recommend` y `simulate_fourth_down`, con `GO_MIN_PROB = 0.50`, `MIN_SAMPLE = 5` y `FG_MAX_YARDLINE = 37`.

### Endpoints (`main.py`)

```
GET  /health                    -> {"status": "ok"}
GET  /api/meta                  -> {simulated, any_simulated, seasons, teams (list_teams + teams_meta), coach_source}
GET  /api/efficiency?season&exclude_garbage_time
GET  /api/matchup?home&away&season&exclude_garbage_time   -> comparación + context (Contexto_Matchup)
POST /api/fourth-down/simulate  {ydstogo, yardline_100}   -> simulación + warnings + context
POST /api/coach/ask             {question, topic, home?, away?, season?, exclude_garbage_time?, ydstogo?, yardline_100?}
app.mount("/", StaticFiles(dashboard/dist, html=True))     # al final, si existe
```

`/api/coach/ask` reconstruye el contexto en el servidor (6.2):
- `topic = "matchup"`: `{"tipo": "matchup", "comparacion": metrics.matchup(...), "contexto": coach.get_matchup_context(home, away)}`. Requiere `home` y `away` distintos.
- `topic = "fourth_down"`: `{"tipo": "fourth_down", "simulacion": simulate_fourth_down(...), "contexto": coach.get_fourth_down_context(...)}`. Requiere `ydstogo` y `yardline_100`.
- Faltan parámetros del tema → 422.

### Contratos (`schemas.py`)

Se conservan `TeamRow`, `TeamInfo`, `EfficiencyResponse`, `MetricComparison`, `CrossMatchup`, `FourthDownRequest` (estricto, 1-30 y 1-99) y `ZonePoint`. Cambios:

```python
class MetaResponse(BaseModel):
    simulated: dict[str, bool]; any_simulated: bool; seasons: list[int]
    teams: list[TeamInfo]; coach_source: Literal["ai_agent", "backend"]

class MatchupResponse(BaseModel):  # + context
    ...; context: dict[str, Any]

class FourthDownResponse(BaseModel):  # + warnings, context
    ...; warnings: list[str]; context: dict[str, Any]

class CoachRequest(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    topic: Literal["matchup", "fourth_down"]
    home: str | None = None; away: str | None = None
    season: int | None = None; exclude_garbage_time: bool = True
    ydstogo: int | None = Field(None, ge=1, le=30, strict=True)
    yardline_100: int | None = Field(None, ge=1, le=99, strict=True)

class CoachResponse(BaseModel):
    text: str; ai_generated: bool; source: Literal["ai_agent", "backend", "determinista"]
```

`warnings` = `context["warnings"]` (solo cadenas) más la advertencia propia de muestra pequeña, sin duplicados.

### Dashboard

```
src/
  App.tsx, api.ts, types.ts, format.ts
  components/
    ui.tsx, SimulatedBanner.tsx, Filters.tsx, EfficiencyQuadrant.tsx,
    MatchupPanel.tsx, FourthDownSimulator.tsx, CoachPanel.tsx
```

- **CoachPanel** (reemplaza a AdvicePanel): recibe `topic`, los parámetros y una pregunta sugerida. Caja de texto editable (máx. 500), botón "Consultar al copiloto". Solo llama a la API en `onClick` (6.3). Spinner y botón deshabilitado mientras espera (6.8). Etiqueta "Generado por IA" o "Recomendación automática (sin IA)" (6.11). La respuesta se borra cuando cambian los parámetros.
- **MatchupPanel**: tablas como antes; si `context` trae `team_a.<métrica>_rank` y `team_b.<métrica>_rank`, se muestra `#n` junto al valor (4.6). Incluye un CoachPanel con `topic="matchup"`.
- **FourthDownSimulator**: tarjeta de recomendación, tabla de las tres opciones (Intentar: EPA y conversión; Gol de campo y Despeje: "Sin datos", con indicación de si la regla los permite), lista de `warnings` (5.8, 5.9), gráfico de barras, y CoachPanel con `topic="fourth_down"`.
- **App**: muestra en el encabezado "Contexto: ai_agent" o "Contexto: respaldo local" según `coach_source`.
- **EfficiencyQuadrant**, **Filters**, **SimulatedBanner** sin cambios.

## Correctness Properties

1. **Ida y vuelta JSON (1.9)** de todas las filas `TeamRow`.
2. **Consistencia (3.12)** con `team_efficiency.csv`, tolerancia 1e-4.
3. **Filtro**: la suma de diferencias de `plays` es 1,316.
4. **Simetría (4.9)** en los 32 × 31 pares.
5. **Invariante 4th down (5.12)** en `ydstogo` 1-30 × `yardline_100` 1-99.
6. **Adaptador (2.2, 2.3)**: con un módulo externo falso que lanza `RuntimeError`, cada función devuelve el resultado local; con `ValueError`, la API responde 404; con un módulo sin alguna función, `source == "backend"`.
7. **Timeout (6.7)**: un `ask_front_office_coach` que tarda más que el límite devuelve el respaldo con `ai_generated: False`.
8. **Sin llamadas automáticas (6.3)**: ningún endpoint distinto de `/api/coach/ask` invoca `ask_front_office_coach` ni `boto3.client` (se comprueba con fakes que cuentan llamadas mientras se recorren los demás endpoints).
9. **JSON seguro (2.5)**: `to_jsonable` de un contexto con `numpy.int64`, `numpy.float64('nan')` y `DataFrame` produce algo que `json.dumps(..., allow_nan=False)` acepta.

## Error Handling

| Situación | Comportamiento |
|---|---|
| `ai_agent/` ausente o con error al importar | `coach_source = "backend"`, todo funciona con el respaldo local |
| Función externa con excepción ≠ `ValueError` | Resultado local para esa llamada |
| `get_matchup_context` con `ValueError` | 404 con el mensaje |
| Copiloto con error, vacío o > 30 s | Respaldo local → texto determinista, `ai_generated: false`, HTTP 200 |
| CSV ausente o sin columnas | Datos_Simulados y aviso |
| Parámetros inválidos | 422 |

## Testing Strategy

- `pytest` + `TestClient`. El módulo externo se simula inyectando un objeto falso en `Coach(external=...)`; `boto3.client` se sustituye con `monkeypatch`. Ninguna prueba llama a AWS.
- Dashboard: `tsc --noEmit`, `vite build` y búsqueda de `'/api`, `localhost`, `127.0.0.1` y `http` en `dashboard/src`.
- Integración: Uvicorn sirviendo `/`, `/health` y `/api/*` en un puerto; `.\.hackathon\setup.cmd --check`.

## Decisiones pendientes

- `ai_agent/bedrock_coach.py` no está en el workspace. El adaptador acepta las formas de respuesta descritas arriba; cuando llegue el archivo hay que confirmar que (a) crea el cliente solo con `region_name`, (b) usa `BEDROCK_MODEL_ID` con el valor por defecto de `rules.md`, (c) no lee ni valida credenciales y (d) no hace llamadas a Bedrock al importarse.
