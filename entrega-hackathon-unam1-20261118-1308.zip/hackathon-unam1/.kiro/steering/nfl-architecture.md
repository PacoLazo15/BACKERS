---
inclusion: always
---
# Contrato Técnico NFL Big Data Bowl - Persona B (FastAPI + React/Vite)
- **Stack Obligatorio (`rules.md`):** Backend en FastAPI + `pandas` leyendo CSVs desde `data/`; Frontend en React + Vite + Recharts; IA con Amazon Bedrock (Nova vía Strands/`boto3`).
- **Datasets en `data/`:**
  - `data/team_efficiency.csv`: `posteam`, `plays`, `yards_per_play`, `success_rate`, `completion_pct`, `sack_rate`, `def_yards_per_play`, `def_success_rate`.
  - `data/plays_clean.csv`: `game_id`, `play_id`, `season`, `week`, `posteam`, `defteam`, `down`, `ydstogo`, `yardline_100`, `qtr`, `game_seconds_remaining`, `score_differential`, `pass_result`, `yards_gained`, `net_yards`, `first_down`, `success`.
- **Regla Estadística:** Datos correspondientes a jugadas de pase (Semanas 1-8, 2021). Excluir tiempo basura filtrando `qtr == 4` y `abs(score_differential) > 16`.
- **Enfoque UI:** War Room de Juego Aéreo y Scouting (Cuadrante de Eficiencia Aérea Ofensiva vs Defensiva, Análisis Situacional por Down/Distancia y Copiloto Táctico con Bedrock).