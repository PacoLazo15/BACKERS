# Copiloto NFL – Hackathon UNAM

Dashboard para analizar la eficiencia ofensiva y defensiva de equipos de la NFL, comparar enfrentamientos y simular decisiones de cuarto down. Incluye un copiloto de IA (Amazon Bedrock) que responde preguntas usando únicamente los datos del dashboard.

Los datos cubren solo jugadas de pase de las semanas 1-8 de 2021.

## Funciones

- **Cuadrante de eficiencia:** EPA ofensivo contra EPA permitido por equipo, con opción de excluir garbage time.
- **Matchup:** comparación de dos equipos con métricas, rankings `#n` y promedio de la liga.
- **Simulador de 4th down:** compara intentar la conversión, patear gol de campo y despejar, con avisos de muestra pequeña.
- **Copiloto:** pregunta editable que se envía solo al presionar el botón. El contexto se arma en el servidor. Si Bedrock no está disponible, responde con un texto determinista de respaldo.

## Estructura

```
backend/          API FastAPI
  main.py         app, endpoints y lifespan
  coach.py        Coach: usa ai_agent.bedrock_coach si existe, si no LocalCoach
  coach_local.py  contexto de matchup y 4th down desde los datos
  advisor.py      llamada a Bedrock (ask_bedrock) y texto de respaldo
  data_loader.py  carga de los CSV de data/
  metrics.py      métricas, matchup y simulación de 4th down
  schemas.py      modelos Pydantic
  scripts/        transform.py y upload_s3.py (pipeline de datos)
dashboard/        React + Vite + Tailwind + Recharts
  src/components/ CoachPanel, MatchupPanel, FourthDownSimulator, EfficiencyQuadrant, ...
data/             CSV: plays_clean, team_efficiency, fourth_down_situations, teams_meta
tests/            pytest
.hackathon/       instalador del entorno (setup.cmd / setup.sh)
.kiro/specs/      requisitos, diseño y tareas
```

## Requisitos

- Python (entorno `.venv`)
- Node 22.23.1
- Credenciales temporales de AWS para Bedrock (opcional; sin ellas se usa el respaldo)

## Instalación

Desde la raíz del proyecto:

```powershell
.\.hackathon\setup.cmd          # crea .venv e instala dependencias
.\.hackathon\setup.cmd --check  # verifica el entorno
```

En Linux o macOS usa `.hackathon/setup.sh`.

Credenciales de AWS:

```powershell
Copy-Item .env.example .env
```

Pega en `.env` las llaves del workshop (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`). Valen unas horas. `.env` no se versiona ni se incluye en el .zip de entrega.

## Ejecución

Backend:

```powershell
.\.venv\Scripts\uvicorn backend.main:app --reload
```

Frontend en desarrollo:

```powershell
cd dashboard
npm install
npm run dev
```

Build de producción. Si existe `dashboard/dist`, FastAPI lo sirve en `/`:

```powershell
cd dashboard
npm run build
```

## API

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/health` | Estado del servicio |
| GET | `/api/meta` | Temporadas, equipos, origen del copiloto (`coach_source`) |
| GET | `/api/efficiency` | Eficiencia por equipo (`season`, `exclude_garbage_time`) |
| GET | `/api/matchup` | Comparación `home` vs `away` con `context` |
| POST | `/api/fourth-down/simulate` | Simulación de 4th down con `warnings` y `context` |
| POST | `/api/coach/ask` | Pregunta al copiloto (único endpoint que consulta Bedrock) |

## Pruebas

```powershell
.\.venv\Scripts\pytest
```

## Integración con `ai_agent`

`backend/coach.py` intenta importar `ai_agent.bedrock_coach`. Ese módulo no está en este repositorio. Si falta o falla, el backend usa `LocalCoach` y `advisor.py`, y `coach_source` lo indica.

## Datos

`backend/scripts/transform.py` genera las tablas curadas y `upload_s3.py` las sube a `s3://<S3_BUCKET_NAME>/curated/`. Si alguna tabla es sintética, el dashboard muestra un aviso de datos simulados.
