const NAMES: Record<string, string> = {
  plays: 'jugadas',
  team_efficiency: 'eficiencia por equipo',
  teams_meta: 'nombres y colores de equipos',
  fourth_down: 'situaciones de 4ta oportunidad',
}

export default function SimulatedBanner({ simulated }: { simulated: Record<string, boolean> }) {
  const list = Object.entries(simulated).filter(([, v]) => v).map(([k]) => NAMES[k] ?? k)
  if (list.length === 0) return null
  return (
    <div className="rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900" role="alert">
      <strong>Datos simulados.</strong> No se pudieron cargar los datos reales de: {list.join(', ')}. Los valores
      mostrados para esos datos son sintéticos y no deben usarse para tomar decisiones.
    </div>
  )
}
