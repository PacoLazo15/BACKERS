import { useEffect, useMemo, useState } from 'react'
import {
  CartesianGrid, Cell, LabelList, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis,
} from 'recharts'
import { api, isAbort } from '../api'
import { median, num, pct, signed } from '../format'
import type { TeamRow } from '../types'
import { Card, Empty, ErrorBox, Spinner } from './ui'

type Point = TeamRow & { def_epa_per_play: number }

function QuadTooltip({ team }: { team?: Point }) {
  if (!team) return null
  return (
    <div className="rounded-md border border-slate-200 bg-white p-3 text-xs shadow-md">
      <p className="mb-1 font-semibold" style={{ color: team.team_color }}>{team.team_name}</p>
      <dl className="grid grid-cols-[auto_auto] gap-x-3 gap-y-0.5 text-slate-700">
        <dt>Jugadas</dt><dd className="text-right">{team.plays}</dd>
        <dt>EPA/jugada</dt><dd className="text-right">{signed(team.epa_per_play)}</dd>
        <dt>EPA permitido/jugada</dt><dd className="text-right">{signed(team.def_epa_per_play)}</dd>
        <dt>Tasa de éxito</dt><dd className="text-right">{pct(team.success_rate)}</dd>
        <dt>Yardas/jugada</dt><dd className="text-right">{num(team.yards_per_play)}</dd>
        <dt>% de pases completos</dt><dd className="text-right">{pct(team.completion_pct)}</dd>
        <dt>% de capturas</dt><dd className="text-right">{pct(team.sack_rate)}</dd>
      </dl>
    </div>
  )
}

const CORNER = 'pointer-events-none absolute text-xs font-semibold uppercase tracking-wide'

export default function EfficiencyQuadrant({ season, excludeGarbage }: { season: number; excludeGarbage: boolean }) {
  const [teams, setTeams] = useState<TeamRow[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const ctrl = new AbortController()
    setError(null)
    api.efficiency(season, excludeGarbage, ctrl.signal)
      .then((r) => setTeams(r.teams))
      .catch((e) => { if (!isAbort(e)) setError(e.message) })
    return () => ctrl.abort()
  }, [season, excludeGarbage])

  const points = useMemo(
    () => (teams ?? []).filter((t): t is Point => t.def_epa_per_play != null),
    [teams],
  )
  const medX = median(points.map((p) => p.epa_per_play))
  const medY = median(points.map((p) => p.def_epa_per_play))

  return (
    <Card
      title="Cuadrante de eficiencia aérea"
      subtitle="EPA por jugada del ataque contra EPA permitido por la defensa. Arriba = mejor defensa; derecha = mejor ataque. Las líneas marcan las medianas."
    >
      {error && <ErrorBox message={error} />}
      {!error && teams === null && <Spinner label="Cargando equipos…" />}
      {!error && teams !== null && points.length === 0 && <Empty message="Sin datos para la selección" />}
      {!error && points.length > 0 && (
        <div className="relative h-[460px]">
          <span className={`${CORNER} right-6 top-2 text-emerald-700`}>Élite (ataque y defensa)</span>
          <span className={`${CORNER} left-20 top-2 text-sky-700`}>Defensa fuerte, ataque débil</span>
          <span className={`${CORNER} bottom-12 right-6 text-amber-700`}>Ataque fuerte, defensa débil</span>
          <span className={`${CORNER} bottom-12 left-20 text-red-700`}>En problemas</span>
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 28, right: 24, bottom: 28, left: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                type="number" dataKey="epa_per_play" name="EPA/jugada" domain={['auto', 'auto']}
                tickFormatter={(v: number) => v.toFixed(2)}
                label={{ value: 'EPA ofensivo por jugada →', position: 'bottom', offset: 8, fontSize: 12 }}
              />
              <YAxis
                type="number" dataKey="def_epa_per_play" name="EPA permitido" reversed domain={['auto', 'auto']}
                tickFormatter={(v: number) => v.toFixed(2)}
                label={{ value: 'EPA permitido por jugada (menor arriba)', angle: -90, position: 'insideLeft', fontSize: 12, dy: 110 }}
              />
              <ReferenceLine x={medX} stroke="#64748b" strokeDasharray="4 4" />
              <ReferenceLine y={medY} stroke="#64748b" strokeDasharray="4 4" />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={(p) => <QuadTooltip team={p.active ? (p.payload?.[0]?.payload as Point | undefined) : undefined} />}
              />
              <Scatter data={points} isAnimationActive={false}>
                {points.map((t) => (
                  <Cell key={t.posteam} fill={t.team_color} stroke={t.team_color2 ?? '#1e293b'} strokeWidth={1} />
                ))}
                <LabelList dataKey="posteam" position="top" fontSize={10} fill="#334155" />
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      )}
    </Card>
  )
}
