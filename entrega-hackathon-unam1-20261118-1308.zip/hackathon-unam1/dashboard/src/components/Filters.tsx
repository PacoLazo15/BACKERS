export default function Filters({ seasons, season, onSeason, excludeGarbage, onExcludeGarbage }: {
  seasons: number[]
  season: number
  onSeason: (s: number) => void
  excludeGarbage: boolean
  onExcludeGarbage: (v: boolean) => void
}) {
  return (
    <div className="flex flex-wrap items-center gap-6 rounded-xl border border-slate-200 bg-white px-5 py-3 shadow-sm">
      <label className="flex items-center gap-2 text-sm text-slate-700">
        Temporada
        <select
          className="rounded-md border border-slate-300 px-2 py-1"
          value={season}
          onChange={(e) => onSeason(Number(e.target.value))}
        >
          {seasons.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </label>
      <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700">
        <input
          type="checkbox"
          className="h-4 w-4 accent-emerald-700"
          checked={excludeGarbage}
          onChange={(e) => onExcludeGarbage(e.target.checked)}
        />
        Excluir tiempo basura
        <span className="text-xs text-slate-400">(probabilidad de victoria fuera de 5-95 %)</span>
      </label>
    </div>
  )
}
