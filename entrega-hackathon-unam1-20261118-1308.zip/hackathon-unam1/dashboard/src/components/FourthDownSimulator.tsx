import { useEffect, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api, isAbort } from '../api'
import { OPTION_LABEL, ZONE_LABEL, pct, signed } from '../format'
import type { FourthDownResponse, ZonePoint } from '../types'
import CoachPanel from './CoachPanel'
import { Card, ErrorBox, Spinner } from './ui'

const OPTION_STYLE = {
  go_for_it: 'border-emerald-300 bg-emerald-50 text-emerald-900',
  field_goal: 'border-sky-300 bg-sky-50 text-sky-900',
  punt: 'border-slate-300 bg-slate-50 text-slate-900',
} as const

function Control({ label, value, min, max, onChange, hint }: {
  label: string
  value: number
  min: number
  max: number
  onChange: (v: number) => void
  hint: string
}) {
  const set = (raw: string) => {
    const v = Math.round(Number(raw))
    if (Number.isFinite(v)) onChange(Math.min(max, Math.max(min, v)))
  }
  return (
    <div className="flex-1">
      <label className="flex items-center justify-between text-sm text-slate-700">
        {label}
        <input
          type="number" min={min} max={max} step={1} value={value}
          onChange={(e) => set(e.target.value)}
          className="w-20 rounded-md border border-slate-300 px-2 py-1 text-right"
        />
      </label>
      <input
        type="range" min={min} max={max} step={1} value={value} aria-label={label}
        onChange={(e) => set(e.target.value)} className="mt-2 w-full accent-emerald-700"
      />
      <p className="text-xs text-slate-400">{hint}</p>
    </div>
  )
}

function OptionsTable({ result }: { result: FourthDownResponse }) {
  const rows: { key: FourthDownResponse['recommendation']; value: string; note: string }[] = [
    {
      key: 'go_for_it',
      value: `${signed(result.go_for_it_epa, 2)} EPA · ${pct(result.conversion_prob)}`,
      note: `${result.sample_size} jugadas`,
    },
    {
      key: 'field_goal',
      value: 'Sin datos',
      note: result.field_goal_available ? 'En rango (≤ 37 yardas)' : 'Fuera de rango (> 37 yardas)',
    },
    { key: 'punt', value: 'Sin datos', note: 'Opción por defecto de la regla' },
  ]
  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b border-slate-200 text-left text-xs uppercase text-slate-500">
          <th className="py-1 font-medium">Opción</th>
          <th className="py-1 text-right font-medium">Valor histórico</th>
          <th className="py-1 text-right font-medium">Nota</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.key} className={`border-b border-slate-100 ${r.key === result.recommendation ? 'font-semibold text-emerald-800' : 'text-slate-700'}`}>
            <td className="py-1">{OPTION_LABEL[r.key]}{r.key === result.recommendation && ' ✓'}</td>
            <td className={`py-1 text-right ${r.value === 'Sin datos' ? 'text-slate-400' : ''}`}>{r.value}</td>
            <td className="py-1 text-right text-xs text-slate-500">{r.note}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

function CurveTooltip({ point }: { point?: ZonePoint }) {
  if (!point) return null
  return (
    <div className="rounded-md border border-slate-200 bg-white p-2 text-xs shadow">
      <p className="font-semibold">4ta y {point.ydstogo}</p>
      <p>Conversión: {pct(point.conversion_prob)}</p>
      <p>Muestra: {point.sample_size} jugadas</p>
    </div>
  )
}

export default function FourthDownSimulator() {
  const [ydstogo, setYdstogo] = useState(4)
  const [yardline, setYardline] = useState(35)
  const [result, setResult] = useState<FourthDownResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const ctrl = new AbortController()
    setLoading(true)
    const timer = setTimeout(() => {
      api.simulate({ ydstogo, yardline_100: yardline }, ctrl.signal)
        .then((r) => { setResult(r); setError(null) })
        .catch((e) => { if (!isAbort(e)) setError(e.message) })
        .finally(() => { if (!ctrl.signal.aborted) setLoading(false) })
    }, 250)
    return () => { clearTimeout(timer); ctrl.abort() }
  }, [ydstogo, yardline])

  return (
    <Card
      title="Simulador de 4ta oportunidad"
      subtitle="Regla: intentar si la conversión histórica es ≥ 50 % con al menos 5 jugadas; si no, gol de campo a 37 yardas o menos; si no, despeje."
    >
      <div className="mb-5 flex gap-6">
        <Control label="Yardas por avanzar" value={ydstogo} min={1} max={30} onChange={setYdstogo} hint="1 a 30" />
        <Control
          label="Yardas a la zona de anotación" value={yardline} min={1} max={99} onChange={setYardline}
          hint="1 = a una yarda de anotar · 99 = en tu propia yarda 1"
        />
      </div>

      {error && <ErrorBox message={error} />}
      {!result && !error && <Spinner label="Simulando…" />}
      {result && (
        <div className={`grid grid-cols-1 gap-5 xl:grid-cols-2 ${loading ? 'opacity-60' : ''}`}>
          <div className="space-y-3">
            <div className={`rounded-lg border p-4 ${OPTION_STYLE[result.recommendation]}`}>
              <p className="text-xs uppercase tracking-wide opacity-70">Recomendación</p>
              <p className="text-2xl font-bold">{OPTION_LABEL[result.recommendation]}</p>
              <p className="mt-2 text-sm">{result.rule}</p>
            </div>
            <dl className="grid grid-cols-3 gap-3 text-center">
              <div className="rounded-lg bg-slate-50 p-3">
                <dt className="text-xs text-slate-500">Conversión histórica</dt>
                <dd className="text-xl font-semibold">{pct(result.conversion_prob)}</dd>
              </div>
              <div className="rounded-lg bg-slate-50 p-3">
                <dt className="text-xs text-slate-500">EPA de intentar</dt>
                <dd className="text-xl font-semibold">{signed(result.go_for_it_epa, 2)}</dd>
              </div>
              <div className={`rounded-lg p-3 ${result.low_sample ? 'bg-amber-50' : 'bg-slate-50'}`}>
                <dt className="text-xs text-slate-500">Tamaño de muestra</dt>
                <dd className="text-xl font-semibold">{result.sample_size} jugadas</dd>
              </div>
            </dl>
            <OptionsTable result={result} />
            {result.warnings.length > 0 && (
              <ul className="space-y-1 rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-900">
                {result.warnings.map((w) => <li key={w}>⚠ {w}</li>)}
              </ul>
            )}
            <p className="text-xs text-slate-500">
              Zona: {ZONE_LABEL[result.field_zone] ?? result.field_zone}.{' '}
              {result.exact_match
                ? `Datos exactos para 4ta y ${result.ydstogo}.`
                : `Sin datos para 4ta y ${result.ydstogo} en esta zona; se usa la situación más cercana: 4ta y ${result.matched_ydstogo}${result.matched_field_zone !== result.field_zone ? ` (${ZONE_LABEL[result.matched_field_zone] ?? result.matched_field_zone})` : ''}.`}

            </p>
          </div>
          <div>
            <p className="mb-1 text-sm font-medium text-slate-700">
              Conversión por yardas por avanzar · {ZONE_LABEL[result.matched_field_zone] ?? result.matched_field_zone}
            </p>
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={result.zone_curve} margin={{ top: 8, right: 8, bottom: 16, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="ydstogo" label={{ value: 'Yardas por avanzar', position: 'bottom', offset: 0, fontSize: 12 }} />
                  <YAxis domain={[0, 1]} tickFormatter={(v: number) => `${Math.round(v * 100)} %`} width={48} />
                  <ReferenceLine y={0.5} stroke="#059669" strokeDasharray="4 4" label={{ value: '50 %', position: 'right', fontSize: 11 }} />
                  <Tooltip content={(p) => <CurveTooltip point={p.active ? (p.payload?.[0]?.payload as ZonePoint | undefined) : undefined} />} />
                  <Bar dataKey="conversion_prob" isAnimationActive={false}>
                    {result.zone_curve.map((pt) => (
                      <Cell
                        key={pt.ydstogo}
                        fill={pt.ydstogo === result.matched_ydstogo ? '#047857' : pt.sample_size < 5 ? '#cbd5e1' : '#94a3b8'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="text-xs text-slate-400">Verde oscuro: situación usada. Gris claro: menos de 5 jugadas.</p>
          </div>
          <div className="xl:col-span-2">
            <CoachPanel
              params={{ topic: 'fourth_down', ydstogo: result.ydstogo, yardline_100: result.yardline_100 }}
              paramsKey={`${result.ydstogo}-${result.yardline_100}`}
              suggestion={`¿Debo jugármela en 4ta y ${result.ydstogo} a ${result.yardline_100} yardas de la zona de anotación?`}
            />
          </div>
        </div>
      )}
    </Card>
  )
}
