import { useEffect, useState } from 'react'
import { api } from '../api'
import type { CoachRequest, CoachResponse } from '../types'
import { ErrorBox, Spinner } from './ui'

// Omit distributivo: conserva la unión matchup | fourth_down.
type Params = CoachRequest extends infer R ? (R extends CoachRequest ? Omit<R, 'question'> : never) : never

const SOURCE_LABEL: Record<CoachResponse['source'], string> = {
  ai_agent: 'ai_agent/bedrock_coach',
  backend: 'Bedrock desde el backend',
  determinista: 'regla automática',
}

/**
 * Consulta al copiloto SOLO cuando el usuario presiona el botón (cada consulta gasta créditos de Bedrock).
 * Cambiar los parámetros borra la respuesta anterior, pero no vuelve a consultar.
 */
export default function CoachPanel({ params, paramsKey, suggestion }: {
  params: Params
  paramsKey: string
  suggestion: string
}) {
  const [question, setQuestion] = useState(suggestion)
  const [answer, setAnswer] = useState<CoachResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setAnswer(null)
    setError(null)
    setQuestion(suggestion)
  }, [paramsKey, suggestion])

  const ask = () => {
    const q = question.trim()
    if (!q || loading) return
    setLoading(true)
    setError(null)
    api.ask({ ...params, question: q } as CoachRequest)
      .then(setAnswer)
      .catch((e) => setError(`No se pudo consultar al copiloto: ${e.message}`))
      .finally(() => setLoading(false))
  }

  return (
    <div className="rounded-lg border border-slate-200 p-4">
      <div className="mb-2 flex items-baseline justify-between gap-4">
        <h3 className="text-sm font-semibold text-slate-800">Copiloto táctico</h3>
        <p className="text-xs text-slate-400">Cada consulta usa créditos de Amazon Bedrock</p>
      </div>
      <div className="flex gap-2">
        <input
          type="text" value={question} maxLength={500} aria-label="Pregunta para el copiloto"
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') ask() }}
          className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
        <button
          type="button" onClick={ask} disabled={loading || !question.trim()}
          className="rounded-md bg-emerald-700 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-800 disabled:opacity-50"
        >
          Consultar al copiloto
        </button>
      </div>
      {loading && <div className="mt-3"><Spinner label="El copiloto está analizando…" /></div>}
      {error && <div className="mt-3"><ErrorBox message={error} /></div>}
      {answer && !loading && (
        <div className="mt-3">
          <span
            className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium ${
              answer.ai_generated ? 'bg-violet-100 text-violet-800' : 'bg-slate-100 text-slate-700'
            }`}
          >
            {answer.ai_generated ? 'Generado por IA' : 'Recomendación automática (sin IA)'}
          </span>
          <span className="ml-2 text-xs text-slate-400">Fuente: {SOURCE_LABEL[answer.source]}</span>
          <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-slate-800">{answer.text}</p>
        </div>
      )}
    </div>
  )
}
