import { useEffect, useState } from 'react'
import { api, isAbort } from '../api'
import { METRICS, metricDiff, metricValue, signed } from '../format'
import type { Context, CrossMatchup, MatchupResponse, MetricComparison, TeamInfo } from '../types'
import CoachPanel from './CoachPanel'
import { Card, ErrorBox, Spinner } from './ui'

const WIN = 'bg-emerald-50 font-semibold text-emerald-800'

type Side = 'team_a' | 'team_b'

/** Lee context.team_a.<métrica>_rank si existe (ai_agent o respaldo local). */
function rankOf(context: Context, side: Side, metric: string): number | null {
  const team = context[side]
  if (!team || typeof team !== 'object') return null
  const value = (team as Record<string, unknown>)[`${metric}_rank`]
  return typeof value === 'number' ? value : null
}

function Rank({ value }: { value: number | null }) {
  if (value == null) return null
  return <span className="ml-1 text-xs font-normal text-slate-400">#{value}</span>
}

function MetricTable({ title, rows, home, away, context }: {
  title: string
  rows: MetricComparison[]
  home: TeamInfo
  away: TeamInfo
  context: Context
}) {
  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold text-slate-700">{title}</h3>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-slate-200 text-left text-xs uppercase text-slate-500">
            <th className="py-1.5 font-medium">Métrica</th>
            <th className="py-1.5 text-right font-medium" style={{ color: home.team_color }}>{home.posteam} (local)</th>
            <th className="py-1.5 text-right font-medium" style={{ color: away.team_color }}>{away.posteam} (visitante)</th>
            <th className="py-1.5 text-right font-medium">Diferencia</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((m) => (
            <tr key={m.metric} className="border-b border-slate-100">
              <td className="py-1.5 text-slate-700">
                {METRICS[m.metric]?.label ?? m.metric}
                {m.lower_is_better && <span className="ml-1 text-xs text-slate-400">(menor es mejor)</span>}
              </td>
              <td className={`px-2 py-1.5 text-right ${m.better === 'home' ? WIN : ''}`}>
                {metricValue(m.metric, m.home)}<Rank value={rankOf(context, 'team_a', m.metric)} />
              </td>
              <td className={`px-2 py-1.5 text-right ${m.better === 'away' ? WIN : ''}`}>
                {metricValue(m.metric, m.away)}<Rank value={rankOf(context, 'team_b', m.metric)} />
              </td>
              <td className="py-1.5 text-right tabular-nums text-slate-600">{metricDiff(m.metric, m.diff)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function CrossCard({ cross }: { cross: CrossMatchup }) {
  const favors = cross.edge > 0 ? 'ataque' : cross.edge < 0 ? 'defensa' : 'nadie'
  return (
    <div className="rounded-lg border border-slate-200 p-3 text-sm">
      <p className="font-semibold text-slate-800">Ataque {cross.offense_team} vs defensa {cross.defense_team}</p>
      <dl className="mt-2 grid grid-cols-[1fr_auto] gap-y-1 text-slate-600">
        <dt>EPA/jugada de {cross.offense_team}</dt><dd className="text-right">{signed(cross.offense_epa)}</dd>
        <dt>EPA permitido por {cross.defense_team}</dt><dd className="text-right">{signed(cross.defense_epa_allowed)}</dd>
        <dt className="font-medium text-slate-800">Ventaja combinada</dt>
        <dd className={`text-right font-semibold ${cross.edge > 0 ? 'text-emerald-700' : 'text-red-700'}`}>{signed(cross.edge)}</dd>
      </dl>
      <p className="mt-2 text-xs text-slate-500">Suma de ambos EPA. Positivo favorece al ataque; hoy favorece a la {favors}.</p>
    </div>
  )
}

export default function MatchupPanel({ teams, season, excludeGarbage }: {
  teams: TeamInfo[]
  season: number
  excludeGarbage: boolean
}) {
  const codes = teams.map((t) => t.posteam)
  const [home, setHome] = useState(codes.includes('KC') ? 'KC' : codes[0] ?? '')
  const [away, setAway] = useState(codes.includes('BUF') ? 'BUF' : codes[1] ?? '')
  const [data, setData] = useState<MatchupResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const same = home === away

  useEffect(() => {
    if (same || !home || !away) return
    const ctrl = new AbortController()
    setLoading(true)
    setError(null)
    api.matchup(home, away, season, excludeGarbage, ctrl.signal)
      .then(setData)
      .catch((e) => { if (!isAbort(e)) { setError(e.message); setData(null) } })
      .finally(() => { if (!ctrl.signal.aborted) setLoading(false) })
    return () => ctrl.abort()
  }, [home, away, season, excludeGarbage, same])

  const select = (value: string, onChange: (v: string) => void, label: string) => (
    <label className="flex flex-1 flex-col gap-1 text-sm text-slate-700">
      {label}
      <select className="rounded-md border border-slate-300 px-2 py-1.5" value={value} onChange={(e) => onChange(e.target.value)}>
        {teams.map((t) => <option key={t.posteam} value={t.posteam}>{t.team_name} ({t.posteam})</option>)}
      </select>
    </label>
  )

  return (
    <Card title="Matchup" subtitle="Compara dos equipos. Se resalta el mejor valor de cada métrica.">
      <div className="mb-4 flex gap-4">
        {select(home, setHome, 'Equipo local')}
        {select(away, setAway, 'Equipo visitante')}
      </div>
      {same && <ErrorBox message="Selecciona dos equipos distintos" />}
      {!same && error && <ErrorBox message={error} />}
      {!same && !error && loading && !data && <Spinner label="Comparando…" />}
      {!same && !error && data && (
        <div className={`space-y-5 ${loading ? 'opacity-60' : ''}`}>
          <MetricTable title="Métricas principales (EPA)" rows={data.primary} home={data.home} away={data.away} context={data.context} />
          <div className="grid grid-cols-2 gap-3">
            <CrossCard cross={data.home_offense_vs_away_defense} />
            <CrossCard cross={data.away_offense_vs_home_defense} />
          </div>
          <MetricTable title="Detalle: métricas complementarias" rows={data.complementary} home={data.home} away={data.away} context={data.context} />
          <p className="text-xs text-slate-400">#n = posición en la liga (1 = mejor).</p>
        </div>
      )}
      {!same && (
        <div className="mt-5">
          <CoachPanel
            params={{ topic: 'matchup', home, away, season, exclude_garbage_time: excludeGarbage }}
            paramsKey={`${home}-${away}-${season}-${excludeGarbage}`}
            suggestion={`¿Qué ventaja táctica tiene ${home} sobre ${away} en el juego aéreo?`}
          />
        </div>
      )}
    </Card>
  )
}
