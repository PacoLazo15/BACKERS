import { useEffect, useState } from 'react'
import { api } from './api'
import EfficiencyQuadrant from './components/EfficiencyQuadrant'
import Filters from './components/Filters'
import FourthDownSimulator from './components/FourthDownSimulator'
import MatchupPanel from './components/MatchupPanel'
import SimulatedBanner from './components/SimulatedBanner'
import { ErrorBox, Spinner } from './components/ui'
import type { Meta } from './types'

export default function App() {
  const [meta, setMeta] = useState<Meta | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [season, setSeason] = useState<number | null>(null)
  const [excludeGarbage, setExcludeGarbage] = useState(true)

  useEffect(() => {
    api.meta()
      .then((m) => {
        setMeta(m)
        setSeason(m.seasons[m.seasons.length - 1] ?? null)
      })
      .catch((e) => setError(`No se pudo conectar con la API: ${e.message}`))
  }, [])

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <header className="bg-slate-900 px-6 py-4 text-white">
        <h1 className="text-xl font-bold">War Room · Copiloto de Estrategia NFL</h1>
        <p className="text-sm text-slate-300">
          Juego aéreo, temporada 2021, semanas 1-8 (Big Data Bowl + nflverse)
          {meta && (
            <span className="ml-3 rounded bg-slate-700 px-2 py-0.5 text-xs">
              Contexto: {meta.coach_source === 'ai_agent' ? 'ai_agent/bedrock_coach' : 'respaldo local del backend'}
            </span>
          )}
        </p>
      </header>
      <main className="mx-auto max-w-[1600px] space-y-4 px-6 py-5">
        {error && <ErrorBox message={error} />}
        {!meta && !error && <Spinner label="Cargando datos…" />}
        {meta && season !== null && (
          <>
            <SimulatedBanner simulated={meta.simulated} />
            <Filters
              seasons={meta.seasons}
              season={season}
              onSeason={setSeason}
              excludeGarbage={excludeGarbage}
              onExcludeGarbage={setExcludeGarbage}
            />
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <EfficiencyQuadrant season={season} excludeGarbage={excludeGarbage} />
              <MatchupPanel teams={meta.teams} season={season} excludeGarbage={excludeGarbage} />
            </div>
            <FourthDownSimulator />
          </>
        )}
      </main>
    </div>
  )
}
