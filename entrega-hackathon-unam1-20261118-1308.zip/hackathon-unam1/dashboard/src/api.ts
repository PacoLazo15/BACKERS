// Todas las rutas son relativas y SIN diagonal inicial: la app se publica en una subruta.
import type {
  CoachRequest, CoachResponse, EfficiencyResponse, FourthDownRequest, FourthDownResponse, MatchupResponse, Meta,
} from './types'

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`api/${path}`, init)
  if (!res.ok) {
    let message = `Error ${res.status}`
    try {
      const body = await res.json()
      if (typeof body.detail === 'string') message = body.detail
    } catch {
      // respuesta sin JSON
    }
    throw new ApiError(res.status, message)
  }
  return res.json() as Promise<T>
}

function post<T>(path: string, body: unknown, signal?: AbortSignal): Promise<T> {
  return request<T>(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  })
}

export const api = {
  meta: () => request<Meta>('meta'),
  efficiency: (season: number, excludeGarbage: boolean, signal?: AbortSignal) =>
    request<EfficiencyResponse>(`efficiency?season=${season}&exclude_garbage_time=${excludeGarbage}`, { signal }),
  matchup: (home: string, away: string, season: number, excludeGarbage: boolean, signal?: AbortSignal) =>
    request<MatchupResponse>(
      `matchup?home=${encodeURIComponent(home)}&away=${encodeURIComponent(away)}` +
        `&season=${season}&exclude_garbage_time=${excludeGarbage}`,
      { signal },
    ),
  simulate: (body: FourthDownRequest, signal?: AbortSignal) =>
    post<FourthDownResponse>('fourth-down/simulate', body, signal),
  /** Única llamada que consume créditos de Bedrock: solo se usa desde el botón de CoachPanel. */
  ask: (body: CoachRequest) => post<CoachResponse>('coach/ask', body),
}

export function isAbort(e: unknown): boolean {
  return e instanceof DOMException && e.name === 'AbortError'
}
