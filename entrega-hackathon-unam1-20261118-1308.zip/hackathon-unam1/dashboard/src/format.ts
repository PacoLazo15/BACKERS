import type { FourthOption } from './types'

type Kind = 'epa' | 'pct' | 'num' | 'cpoe'

export const METRICS: Record<string, { label: string; kind: Kind }> = {
  epa_per_play: { label: 'EPA/jugada', kind: 'epa' },
  success_rate: { label: 'Tasa de éxito', kind: 'pct' },
  pass_epa: { label: 'EPA en pases', kind: 'epa' },
  run_epa: { label: 'EPA en scrambles', kind: 'epa' },
  cpoe: { label: 'CPOE', kind: 'cpoe' },
  def_epa_per_play: { label: 'EPA permitido/jugada', kind: 'epa' },
  def_success_rate: { label: 'Éxito permitido', kind: 'pct' },
  yards_per_play: { label: 'Yardas/jugada', kind: 'num' },
  completion_pct: { label: '% de pases completos', kind: 'pct' },
  sack_rate: { label: '% de capturas', kind: 'pct' },
}

export function pct(x: number | null | undefined, digits = 1): string {
  return x == null ? '—' : `${(x * 100).toFixed(digits)} %`
}

export function num(x: number | null | undefined, digits = 2): string {
  return x == null ? '—' : x.toFixed(digits)
}

export function signed(x: number | null | undefined, digits = 3): string {
  return x == null ? '—' : `${x > 0 ? '+' : ''}${x.toFixed(digits)}`
}

export function metricValue(metric: string, x: number | null | undefined): string {
  const kind = METRICS[metric]?.kind ?? 'num'
  if (kind === 'pct') return pct(x)
  if (kind === 'epa') return signed(x)
  if (kind === 'cpoe') return signed(x, 1)
  return num(x)
}

/** Diferencia en la unidad de la métrica (puntos porcentuales para tasas). */
export function metricDiff(metric: string, x: number | null): string {
  if (x == null) return '—'
  const kind = METRICS[metric]?.kind ?? 'num'
  if (kind === 'pct') return `${x > 0 ? '+' : ''}${(x * 100).toFixed(1)} pp`
  if (kind === 'epa') return signed(x)
  return signed(x, kind === 'cpoe' ? 1 : 2)
}

export const OPTION_LABEL: Record<FourthOption, string> = {
  go_for_it: 'Intentar (Go For It)',
  field_goal: 'Gol de campo (Field Goal)',
  punt: 'Despeje (Punt)',
}

export const ZONE_LABEL: Record<string, string> = {
  'RedZone (1-20)': 'Zona roja (1-20)',
  'Opponent Territory (21-50)': 'Campo rival (21-50)',
  'Own Territory (51-99)': 'Campo propio (51-99)',
}

export function median(values: number[]): number {
  if (values.length === 0) return 0
  const s = [...values].sort((a, b) => a - b)
  const mid = Math.floor(s.length / 2)
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2
}
