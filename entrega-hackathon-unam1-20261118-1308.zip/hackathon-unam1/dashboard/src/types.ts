export interface TeamInfo {
  posteam: string
  team_name: string
  team_conf: string | null
  team_division: string | null
  team_color: string
  team_color2: string | null
}

export interface TeamRow extends TeamInfo {
  season: number
  plays: number
  epa_per_play: number
  success_rate: number
  pass_epa: number | null
  run_epa: number | null
  cpoe: number | null
  early_down_pass_rate: number | null
  def_epa_per_play: number | null
  def_success_rate: number | null
  yards_per_play: number | null
  completion_pct: number | null
  sack_rate: number | null
}

export interface Meta {
  simulated: Record<string, boolean>
  any_simulated: boolean
  seasons: number[]
  teams: TeamInfo[]
  coach_source: 'ai_agent' | 'backend'
}

/** Contexto devuelto por ai_agent/bedrock_coach.py o por el respaldo local; su forma puede variar. */
export type Context = Record<string, unknown>

export interface EfficiencyResponse {
  season: number
  exclude_garbage_time: boolean
  simulated: boolean
  teams: TeamRow[]
}

export type Better = 'home' | 'away' | 'tie'

export interface MetricComparison {
  metric: string
  home: number | null
  away: number | null
  diff: number | null
  better: Better
  lower_is_better: boolean
}

export interface CrossMatchup {
  offense_team: string
  defense_team: string
  offense_epa: number
  defense_epa_allowed: number
  edge: number
}

export interface MatchupResponse {
  season: number
  exclude_garbage_time: boolean
  home: TeamRow
  away: TeamRow
  primary: MetricComparison[]
  complementary: MetricComparison[]
  home_offense_vs_away_defense: CrossMatchup
  away_offense_vs_home_defense: CrossMatchup
  simulated: boolean
  context: Context
}

export type FourthOption = 'go_for_it' | 'field_goal' | 'punt'

export interface FourthDownRequest {
  ydstogo: number
  yardline_100: number
}

export interface ZonePoint {
  ydstogo: number
  conversion_prob: number
  sample_size: number
}

export interface FourthDownResponse extends FourthDownRequest {
  field_zone: string
  matched_ydstogo: number
  matched_field_zone: string
  exact_match: boolean
  go_for_it_epa: number
  conversion_prob: number
  sample_size: number
  low_sample: boolean
  field_goal_available: boolean
  recommendation: FourthOption
  rule: string
  zone_curve: ZonePoint[]
  simulated: boolean
  warnings: string[]
  context: Context
}

export type CoachRequest =
  | { question: string; topic: 'matchup'; home: string; away: string; season: number; exclude_garbage_time: boolean }
  | { question: string; topic: 'fourth_down'; ydstogo: number; yardline_100: number }

export interface CoachResponse {
  text: string
  ai_generated: boolean
  source: 'ai_agent' | 'backend' | 'determinista'
}
