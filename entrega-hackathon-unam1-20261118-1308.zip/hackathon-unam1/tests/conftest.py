import pandas as pd
import pytest
from fastapi.testclient import TestClient

from backend.data_loader import DATA, load_store
from backend.main import create_app


@pytest.fixture(scope="session")
def store():
    return load_store()


@pytest.fixture(scope="session")
def plays():
    return pd.read_csv(DATA / "plays_clean.csv")


@pytest.fixture(scope="session")
def team_csv():
    return pd.read_csv(DATA / "team_efficiency.csv")


@pytest.fixture(scope="session")
def client():
    # external=None: las pruebas no dependen de que ai_agent/ exista ni lo llaman.
    with TestClient(create_app(external=None)) as c:
        yield c
