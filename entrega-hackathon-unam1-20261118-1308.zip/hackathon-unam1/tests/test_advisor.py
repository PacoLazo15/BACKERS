"""Copiloto sin ai_agent: Bedrock vía boto3 (simulado) y texto determinista."""
import botocore.exceptions
import pytest

from backend import advisor

FOURTH = {"question": "¿Qué hago?", "topic": "fourth_down", "ydstogo": 2, "yardline_100": 35}
MATCHUP = {"question": "¿Quién tiene ventaja?", "topic": "matchup", "home": "KC", "away": "BUF"}


class FakeClient:
    def __init__(self, behaviour):
        self.behaviour = behaviour
        self.kwargs = None

    def converse(self, **kwargs):
        self.kwargs = kwargs
        if isinstance(self.behaviour, Exception):
            raise self.behaviour
        return {"output": {"message": {"content": [{"text": self.behaviour}]}}}


def patch_client(monkeypatch, behaviour):
    fake = FakeClient(behaviour)
    calls = {"n": 0}

    def factory(service, region_name=None, config=None):
        calls.update(service=service, region_name=region_name, config=config, n=calls["n"] + 1)
        return fake

    monkeypatch.setattr(advisor.boto3, "client", factory)
    return fake, calls


def test_exito_usa_modelo_y_region_por_defecto(monkeypatch, client):
    monkeypatch.delenv("BEDROCK_MODEL_ID", raising=False)
    monkeypatch.delenv("AWS_REGION", raising=False)
    fake, calls = patch_client(monkeypatch, "Intenta la conversión.")
    body = client.post("/api/coach/ask", json=FOURTH).json()
    assert body == {"text": "Intenta la conversión.", "ai_generated": True, "source": "backend"}
    assert calls["service"] == "bedrock-runtime" and calls["region_name"] == "us-east-1"
    assert calls["config"].read_timeout == 30
    assert fake.kwargs["modelId"] == "us.amazon.nova-pro-v1:0"
    sent = fake.kwargs["messages"][0]["content"][0]["text"]
    assert "fourth_down" in sent and "¿Qué hago?" in sent


def test_respeta_variables(monkeypatch, client):
    monkeypatch.setenv("BEDROCK_MODEL_ID", "us.amazon.nova-lite-v1:0")
    monkeypatch.setenv("AWS_REGION", "us-west-2")
    fake, calls = patch_client(monkeypatch, "ok")
    client.post("/api/coach/ask", json=MATCHUP)
    assert fake.kwargs["modelId"] == "us.amazon.nova-lite-v1:0" and calls["region_name"] == "us-west-2"


@pytest.mark.parametrize("error", [
    botocore.exceptions.ClientError({"Error": {"Code": "AccessDenied", "Message": "x"}}, "Converse"),
    botocore.exceptions.ReadTimeoutError(endpoint_url="bedrock"),
    botocore.exceptions.NoCredentialsError(),
])
def test_error_usa_texto_determinista(monkeypatch, client, error):
    patch_client(monkeypatch, error)
    body = client.post("/api/coach/ask", json=FOURTH).json()
    assert body["ai_generated"] is False and body["source"] == "determinista"
    assert "Recomendación: intentar la conversión" in body["text"]


def test_respaldo_matchup(monkeypatch, client):
    patch_client(monkeypatch, RuntimeError("sin red"))
    body = client.post("/api/coach/ask", json=MATCHUP).json()
    assert body["ai_generated"] is False
    assert "Ataque KC vs defensa BUF" in body["text"]


def test_respuesta_vacia_usa_respaldo(monkeypatch, client):
    patch_client(monkeypatch, "  ")
    assert client.post("/api/coach/ask", json=FOURTH).json()["ai_generated"] is False


@pytest.mark.parametrize("payload", [
    {**FOURTH, "question": ""},
    {**FOURTH, "question": "x" * 501},
    {"question": "hola", "topic": "fourth_down", "ydstogo": 2},
    {"question": "hola", "topic": "matchup", "home": "KC"},
    {**FOURTH, "ydstogo": 31},
    {**FOURTH, "topic": "otro"},
])
def test_ask_422(client, payload):
    assert client.post("/api/coach/ask", json=payload).status_code == 422


def test_ask_matchup_mismo_equipo(client):
    assert client.post("/api/coach/ask", json={**MATCHUP, "away": "KC"}).status_code == 400


def test_ningun_otro_endpoint_llama_a_bedrock(monkeypatch, client):
    """Propiedad 8 (6.3): solo /api/coach/ask invoca al copiloto."""
    _, calls = patch_client(monkeypatch, "no debería llamarse")
    client.get("/api/meta")
    client.get("/api/efficiency")
    client.get("/api/efficiency?exclude_garbage_time=false")
    client.get("/api/matchup?home=KC&away=BUF")
    for y in (1, 5, 15):
        client.post("/api/fourth-down/simulate", json={"ydstogo": y, "yardline_100": 30})
    assert calls["n"] == 0
    client.post("/api/coach/ask", json=FOURTH)
    assert calls["n"] == 1
