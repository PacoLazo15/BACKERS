import itertools

import pandas as pd
import pytest

from backend import metrics

PRIMARY_CSV = ["plays", "epa_per_play", "success_rate", "pass_epa", "run_epa", "cpoe",
               "early_down_pass_rate", "def_epa_per_play", "def_success_rate"]


def test_recalculo_coincide_con_team_efficiency(plays, team_csv):
    """Propiedad 2 (2.12): sin tiempo basura, el recálculo reproduce team_efficiency.csv."""
    calc = metrics.team_metrics(plays, exclude_garbage_time=True).set_index(metrics.KEYS).sort_index()
    ref = team_csv.set_index(metrics.KEYS).sort_index()
    assert list(calc.index) == list(ref.index)
    for col in PRIMARY_CSV:
        diff = (calc[col] - ref[col]).abs().max()
        assert diff <= 1e-4, f"{col}: {diff}"


def test_filtro_tiempo_basura(plays):
    """Propiedad 3: con filtro hay menos o igual jugadas y la diferencia total son las de garbage_time."""
    with_f = metrics.team_metrics(plays, True).set_index("posteam")["plays"]
    without = metrics.team_metrics(plays, False).set_index("posteam")["plays"]
    assert (without >= with_f).all()
    assert int((without - with_f).sum()) == int(plays["garbage_time"].sum()) == 1316


def test_complementarias(plays):
    comp = metrics.complementary_metrics(plays, False).set_index("posteam")
    ari = plays[plays.posteam == "ARI"]
    assert comp.loc["ARI", "yards_per_play"] == pytest.approx(ari.yards_gained.mean())
    att = ari.pass_result.isin(["C", "I", "IN"]).sum()
    assert comp.loc["ARI", "completion_pct"] == pytest.approx((ari.pass_result == "C").sum() / att)
    assert comp.loc["ARI", "sack_rate"] == pytest.approx((ari.pass_result == "S").mean())


def test_store_tiene_meta_y_sin_logos(store):
    for exclude in (True, False):
        df = store.efficiency[exclude]
        assert len(df) == 32
        assert "team_logo_espn" not in df.columns
        assert df["team_name"].notna().all() and df["team_color"].str.startswith("#").all()
    assert not store.any_simulated


def test_simetria_matchup(store):
    """Propiedad 4 (3.9): diff(A, B) == -diff(B, A) y el ganador se invierte."""
    flip = {"home": "away", "away": "home", "tie": "tie"}
    for exclude in (True, False):
        eff = store.efficiency[exclude]
        for a, b in itertools.permutations(eff["posteam"], 2):
            ab, ba = metrics.matchup(eff, a, b), metrics.matchup(eff, b, a)
            for x, y in zip(ab["primary"] + ab["complementary"], ba["primary"] + ba["complementary"]):
                assert x["metric"] == y["metric"]
                if x["diff"] is None:
                    assert y["diff"] is None
                    continue
                assert x["diff"] == -y["diff"]
                assert x["better"] == flip[y["better"]]


def test_matchup_menor_es_mejor(store):
    eff = store.efficiency[True]
    r = metrics.matchup(eff, "KC", "BUF")
    by = {m["metric"]: m for m in r["primary"] + r["complementary"]}
    for name in ("def_epa_per_play", "sack_rate"):
        m = by[name]
        assert m["lower_is_better"]
        assert m["better"] == ("home" if m["home"] < m["away"] else "away")


def test_matchup_equipo_inexistente(store):
    with pytest.raises(KeyError):
        metrics.matchup(store.efficiency[True], "KC", "XXX")


@pytest.mark.parametrize("y,zone", [(1, metrics.ZONE_RED), (20, metrics.ZONE_RED), (21, metrics.ZONE_OPP),
                                    (50, metrics.ZONE_OPP), (51, metrics.ZONE_OWN), (99, metrics.ZONE_OWN)])
def test_field_zone(y, zone):
    assert metrics.field_zone(y) == zone


def test_invariante_recomendacion_y_vecino(store):
    """Propiedades 5 y 6 (4.4, 4.12) para todo el dominio de entrada."""
    fd = store.fourth_down
    for ydstogo in range(1, 31):
        for yl in range(1, 100):
            r = metrics.simulate_fourth_down(fd, ydstogo, yl)
            go = r["conversion_prob"] >= 0.5 and r["sample_size"] >= 5
            expected = "go_for_it" if go else ("field_goal" if yl <= 37 else "punt")
            assert r["recommendation"] == expected
            if yl > 37:
                assert r["recommendation"] != "field_goal" and not r["field_goal_available"]
            zone_rows = fd[fd.field_zone == r["field_zone"]]
            assert r["matched_field_zone"] == r["field_zone"]
            best = (zone_rows.ydstogo - ydstogo).abs().min()
            assert abs(r["matched_ydstogo"] - ydstogo) == best
            assert r["exact_match"] == (best == 0)


def test_empate_elige_ydstogo_menor():
    fd = pd.DataFrame({"ydstogo": [2, 4], "field_zone": [metrics.ZONE_OPP] * 2,
                       "go_for_it_epa": [0.1, 0.2], "conversion_prob": [0.6, 0.4], "sample_size": [10, 10]})
    assert metrics.simulate_fourth_down(fd, 3, 30)["matched_ydstogo"] == 2


def test_zona_vacia_busca_en_todas():
    fd = pd.DataFrame({"ydstogo": [3], "field_zone": [metrics.ZONE_OWN],
                       "go_for_it_epa": [0.1], "conversion_prob": [0.6], "sample_size": [10]})
    r = metrics.simulate_fourth_down(fd, 3, 10)
    assert r["matched_field_zone"] == metrics.ZONE_OWN and not r["exact_match"]


def test_ejemplos_regla():
    assert metrics.recommend(0.5, 5, 80)[0] == "go_for_it"
    assert metrics.recommend(0.9, 4, 37)[0] == "field_goal"
    assert metrics.recommend(0.49, 20, 38)[0] == "punt"
