import pytest
from fastapi.testclient import TestClient

from backend.main import create_app
from backend.schemas import TeamRow


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_meta(client):
    body = client.get("/api/meta").json()
    assert body["seasons"] == [2021]
    assert len(body["teams"]) == 32
    assert body["any_simulated"] is False
    assert body["coach_source"] == "backend"
    assert "team_logo_espn" not in body["teams"][0]
    assert body["teams"][0]["team_name"] == "Arizona Cardinals"


@pytest.mark.parametrize("exclude", ["true", "false"])
def test_efficiency(client, exclude):
    r = client.get(f"/api/efficiency?season=2021&exclude_garbage_time={exclude}")
    assert r.status_code == 200
    teams = r.json()["teams"]
    assert len(teams) == 32
    for key in ("epa_per_play", "def_epa_per_play", "yards_per_play", "completion_pct", "sack_rate", "team_color"):
        assert key in teams[0]


def test_efficiency_filtro_por_defecto_y_cambia(client):
    default = client.get("/api/efficiency").json()
    assert default["exclude_garbage_time"] is True
    on = {t["posteam"]: t["plays"] for t in default["teams"]}
    off = {t["posteam"]: t["plays"] for t in client.get("/api/efficiency?exclude_garbage_time=false").json()["teams"]}
    assert sum(off.values()) - sum(on.values()) == 1316


def test_efficiency_temporada_sin_datos(client):
    assert client.get("/api/efficiency?season=1999").json()["teams"] == []


def test_ida_y_vuelta_json(client):
    """Propiedad 1 (1.9)."""
    for exclude in ("true", "false"):
        for t in client.get(f"/api/efficiency?exclude_garbage_time={exclude}").json()["teams"]:
            row = TeamRow(**t)
            assert TeamRow.model_validate_json(row.model_dump_json()) == row


def test_matchup(client):
    body = client.get("/api/matchup?home=KC&away=BUF&season=2021").json()
    assert [m["metric"] for m in body["primary"]] == [
        "epa_per_play", "success_rate", "pass_epa", "run_epa", "cpoe", "def_epa_per_play"]
    assert [m["metric"] for m in body["complementary"]] == ["yards_per_play", "completion_pct", "sack_rate"]
    cross = body["home_offense_vs_away_defense"]
    assert cross["offense_team"] == "KC" and cross["defense_team"] == "BUF"
    ctx = body["context"]
    assert ctx["team_a"]["posteam"] == "KC" and 1 <= ctx["team_a"]["epa_per_play_rank"] <= 32
    assert "epa_per_play" in ctx["league_avg"]


def test_matchup_mismo_equipo(client):
    r = client.get("/api/matchup?home=KC&away=KC")
    assert r.status_code == 400


def test_matchup_404_nombra_equipo(client):
    r = client.get("/api/matchup?home=KC&away=XXX")
    assert r.status_code == 404
    assert "XXX" in r.json()["detail"]


def test_simulate(client):
    r = client.post("/api/fourth-down/simulate", json={"ydstogo": 2, "yardline_100": 35})
    assert r.status_code == 200
    body = r.json()
    assert body["field_zone"] == "Opponent Territory (21-50)"
    assert body["recommendation"] == "go_for_it"
    assert body["sample_size"] == 16
    assert body["zone_curve"]
    assert body["context"]["exact"]["ydstogo"] == 2
    assert any("gol de campo" in w for w in body["warnings"])


def test_simulate_muestra_pequena_advierte(client):
    # 4ta y 9 en campo rival: sample_size = 1
    body = client.post("/api/fourth-down/simulate", json={"ydstogo": 9, "yardline_100": 40}).json()
    assert body["low_sample"] is True
    assert any("Muestra pequeña" in w for w in body["warnings"])
    assert len(body["warnings"]) == len(set(body["warnings"]))


@pytest.mark.parametrize("payload,field", [
    ({"ydstogo": 0, "yardline_100": 50}, "ydstogo"),
    ({"ydstogo": 31, "yardline_100": 50}, "ydstogo"),
    ({"ydstogo": 5, "yardline_100": 0}, "yardline_100"),
    ({"ydstogo": 5, "yardline_100": 100}, "yardline_100"),
    ({"ydstogo": 2.5, "yardline_100": 50}, "ydstogo"),
    ({"ydstogo": "3", "yardline_100": 50}, "ydstogo"),
])
def test_simulate_422(client, payload, field):
    """Propiedad 7 (4.11)."""
    r = client.post("/api/fourth-down/simulate", json=payload)
    assert r.status_code == 422
    assert any(field in err["loc"] for err in r.json()["detail"])


def test_datos_simulados_con_directorio_vacio(tmp_path):
    with TestClient(create_app(tmp_path, external=None)) as c:
        meta = c.get("/api/meta").json()
        assert meta["any_simulated"] is True and all(meta["simulated"].values())
        assert len(c.get("/api/efficiency").json()["teams"]) == 32
        assert c.get("/api/matchup?home=KC&away=BUF").status_code == 200
        assert c.post("/api/fourth-down/simulate", json={"ydstogo": 3, "yardline_100": 40}).status_code == 200
    assert list(tmp_path.iterdir()) == []


def test_csv_sin_columnas_usa_simulados(tmp_path):
    (tmp_path / "fourth_down_situations.csv").write_text("a,b\n1,2\n", encoding="utf-8")
    with TestClient(create_app(tmp_path, external=None)) as c:
        assert c.get("/api/meta").json()["simulated"]["fourth_down"] is True
