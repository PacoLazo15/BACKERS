"""Adaptador hacia ai_agent/bedrock_coach.py con módulos falsos (Propiedades 6, 7 y 9)."""
import json
import sys
import time
import types

import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from backend import coach as coach_mod
from backend.coach import Coach, load_external, to_jsonable
from backend.coach_local import LocalCoach
from backend.main import create_app

FOURTH = {"question": "¿Qué hago?", "topic": "fourth_down", "ydstogo": 2, "yardline_100": 35}


class External:
    """Imita ai_agent.bedrock_coach con comportamiento configurable."""

    def __init__(self, fail=None, answer="Respuesta del agente", delay=0.0):
        self.fail = fail or {}
        self.answer = answer
        self.delay = delay
        self.calls = []

    def _maybe_fail(self, name):
        self.calls.append(name)
        if name in self.fail:
            raise self.fail[name]

    def list_teams(self):
        self._maybe_fail("list_teams")
        return ["KC", "BUF", "ZZZ"]

    def get_matchup_context(self, a, b):
        self._maybe_fail("get_matchup_context")
        return {"team_a": {"posteam": a, "epa_per_play": np.float64(0.2), "epa_per_play_rank": np.int64(3)},
                "team_b": {"posteam": b, "cpoe": float("nan")}, "fuente": "ai_agent"}

    def get_fourth_down_context(self, ydstogo, yl):
        self._maybe_fail("get_fourth_down_context")
        return {"exact": None, "nearby": pd.DataFrame({"ydstogo": [1, 2]}), "warnings": ["aviso externo", 7]}

    def ask_front_office_coach(self, question, context):
        self._maybe_fail("ask_front_office_coach")
        time.sleep(self.delay)
        self.last_context = context
        return self.answer


def make_client(external):
    return TestClient(create_app(external=external))


def test_usa_modulo_externo():
    ext = External()
    with make_client(ext) as c:
        meta = c.get("/api/meta").json()
        assert meta["coach_source"] == "ai_agent"
        assert [t["posteam"] for t in meta["teams"]] == ["KC", "BUF"]  # ZZZ no está en los datos
        m = c.get("/api/matchup?home=KC&away=BUF").json()
        assert m["context"]["fuente"] == "ai_agent"
        assert m["context"]["team_a"]["epa_per_play_rank"] == 3
        assert m["context"]["team_b"]["cpoe"] is None
        sim = c.post("/api/fourth-down/simulate", json={"ydstogo": 2, "yardline_100": 35}).json()
        assert sim["warnings"] == ["aviso externo"]
        assert sim["context"]["nearby"] == [{"ydstogo": 1}, {"ydstogo": 2}]
        assert "ask_front_office_coach" not in ext.calls
        r = c.post("/api/coach/ask", json=FOURTH).json()
        assert r == {"text": "Respuesta del agente", "ai_generated": True, "source": "ai_agent"}
        assert ext.last_context["tipo"] == "fourth_down"
        assert ext.last_context["simulacion"]["recommendation"] == "go_for_it"
        json.dumps(ext.last_context, allow_nan=False)


def test_errores_externos_usan_respaldo_local():
    err = RuntimeError("falla")
    ext = External(fail={n: err for n in ("list_teams", "get_matchup_context", "get_fourth_down_context")})
    with make_client(ext) as c:
        assert len(c.get("/api/meta").json()["teams"]) == 32
        m = c.get("/api/matchup?home=KC&away=BUF").json()
        assert "league_avg" in m["context"]
        sim = c.post("/api/fourth-down/simulate", json={"ydstogo": 2, "yardline_100": 35}).json()
        assert sim["context"]["exact"]["ydstogo"] == 2


def test_value_error_da_404():
    ext = External(fail={"get_matchup_context": ValueError("Equipo XXX no existe")})
    with make_client(ext) as c:
        r = c.get("/api/matchup?home=KC&away=BUF")
        assert r.status_code == 404 and r.json()["detail"] == "Equipo XXX no existe"


def test_ask_externo_falla_sin_segunda_llamada(monkeypatch):
    calls = {"n": 0}
    monkeypatch.setattr(coach_mod.advisor.boto3, "client", lambda *a, **k: calls.__setitem__("n", calls["n"] + 1))
    ext = External(fail={"ask_front_office_coach": RuntimeError("bedrock caído")})
    with make_client(ext) as c:
        r = c.post("/api/coach/ask", json=FOURTH).json()
    assert r["ai_generated"] is False and r["source"] == "determinista"
    assert calls["n"] == 0


def test_ask_respuesta_dict_y_vacia(store):
    local = LocalCoach(store)
    assert Coach(local, External(answer={"answer": "hola"})).ask("q", {})["text"] == "hola"
    assert Coach(local, External(answer="")).ask("q", {})["ai_generated"] is False


def test_ask_timeout(store):
    """Propiedad 7: un agente lento devuelve el respaldo dentro del límite."""
    c = Coach(LocalCoach(store), External(delay=1.0), ask_timeout=0.1)
    t = time.perf_counter()
    r = c.ask("q", {"tipo": "fourth_down"})
    assert r["ai_generated"] is False and time.perf_counter() - t < 0.8


def test_load_external_ausente_o_incompleto(monkeypatch):
    assert load_external("ai_agent_que_no_existe.bedrock_coach") is None
    incompleto = types.ModuleType("fake_coach_incompleto")
    incompleto.list_teams = lambda: []
    monkeypatch.setitem(sys.modules, "fake_coach_incompleto", incompleto)
    assert load_external("fake_coach_incompleto") is None
    completo = types.ModuleType("fake_coach_completo")
    for n in coach_mod.REQUIRED:
        setattr(completo, n, lambda *a: None)
    monkeypatch.setitem(sys.modules, "fake_coach_completo", completo)
    assert load_external("fake_coach_completo") is completo


def test_load_external_error_al_importar(monkeypatch, tmp_path):
    (tmp_path / "coach_roto.py").write_text("raise RuntimeError('falta .env')\n", encoding="utf-8")
    monkeypatch.syspath_prepend(str(tmp_path))
    assert load_external("coach_roto") is None


def test_to_jsonable():
    obj = {"a": np.int64(3), "b": np.float64("nan"), "c": [np.float32(1.5), float("inf")],
           "d": pd.DataFrame({"x": [1, None]}), "e": (1, 2), 5: pd.NA}
    out = to_jsonable(obj)
    json.dumps(out, allow_nan=False)
    assert out == {"a": 3, "b": None, "c": [1.5, None], "d": [{"x": 1.0}, {"x": None}], "e": [1, 2], "5": None}


def test_contexto_local(store):
    local = LocalCoach(store)
    ctx = local.get_matchup_context("KC", "BUF")
    assert ctx["teams_in_league"] == 32
    for m in ("epa_per_play", "def_epa_per_play", "sack_rate"):
        assert 1 <= ctx["team_a"][f"{m}_rank"] <= 32
    eff = store.efficiency[True]
    best_def = eff.loc[eff.def_epa_per_play.idxmin(), "posteam"]
    other = "KC" if best_def != "KC" else "BUF"
    assert local.get_matchup_context(best_def, other)["team_a"]["def_epa_per_play_rank"] == 1
    with pytest.raises(ValueError):
        local.get_matchup_context("KC", "XXX")
    fd = local.get_fourth_down_context(15, 40)
    assert fd["exact"] is None and any("4ta y 1 a 4ta y 10" in w for w in fd["warnings"])
